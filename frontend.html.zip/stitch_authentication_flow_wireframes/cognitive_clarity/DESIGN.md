---
name: Cognitive Clarity
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353943'
  surface-container-lowest: '#0a0e17'
  surface-container-low: '#181b25'
  surface-container: '#1c1f29'
  surface-container-high: '#262a34'
  surface-container-highest: '#31353f'
  on-surface: '#dfe2ef'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dfe2ef'
  inverse-on-surface: '#2c303a'
  outline: '#849495'
  outline-variant: '#3b494b'
  surface-tint: '#00dbe9'
  primary: '#dbfcff'
  on-primary: '#00363a'
  primary-container: '#00f0ff'
  on-primary-container: '#006970'
  inverse-primary: '#006970'
  secondary: '#d1bcff'
  on-secondary: '#3c0090'
  secondary-container: '#7000ff'
  on-secondary-container: '#ddcdff'
  tertiary: '#d9ffe9'
  on-tertiary: '#003825'
  tertiary-container: '#34f6b2'
  on-tertiary-container: '#006d4b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#7df4ff'
  primary-fixed-dim: '#00dbe9'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f54'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d1bcff'
  on-secondary-fixed: '#23005b'
  on-secondary-fixed-variant: '#5700c9'
  tertiary-fixed: '#43ffbb'
  tertiary-fixed-dim: '#00e2a0'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005138'
  background: '#0f131c'
  on-background: '#dfe2ef'
  surface-variant: '#31353f'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a high-tech yet deeply intuitive cognitive companion. Designed specifically for mobile operating environments (iOS and Android), the experience must feel like a frictionless extension of human memory—instant, effortless, and intelligent. 

The emotional signature balances sovereign intelligence with approachable calm. It avoids intimidating enterprise complexity while steering clear of toy-like consumer gamification. The visual style merges **Glassmorphism** with **Minimalist Precision**: deep, immersive dark canvases punctuated by an electric cyan glow that signals active recall, synthesis, and insight. Translucent floating surfaces, crisp border definitions, and generous spatial discipline convey order, high throughput, and cognitive peace.

## Colors

The palette is engineered around an immersive deep space dark theme that makes vibrant data visualizations and memory nodes leap forward with tactile clarity.

- **Primary (`#00f0ff`)**: Electric Cyan. Represents active recall, intelligence flashes, highlighted memory states, primary calls-to-action, and dynamic audio/neural wave visualizers.
- **Secondary (`#7000ff`)**: Deep Synaptic Violet. Serves as a complementary cognitive hue for contextual clusters, deep learning indicators, and subtle gradient shifts.
- **Tertiary (`#00e5a3`)**: Lucid Mint. Used specifically for positive reinforcement, completed recall loops, retention progress markers, and high-confidence metrics.
- **Neutral (`#0a0e17`)**: Obsidian Navy. Grounding tone for the base canvas, paired with elevated dark container tones (`#111726`, `#182238`) and frosted glass overlays. Text neutrals step through high-contrast optical whites (`#F8FAFC`), cool slate body tones (`#94A3B8`), and muted metadata lines (`#475569`).

## Typography

The type scale pairs **Plus Jakarta Sans** for headlines and display contexts with **Inter** for UI labels, dense memory feeds, and body reading. 

Plus Jakarta Sans delivers geometric precision with gentle, ergonomic curves that make high-level titles and recall stats feel inviting and contemporary. Inter guarantees maximum legibility on mobile screens across varied lighting conditions, micro-copy, timestamp badges, and synthesis summaries. Tight tracking is enforced on all headlines above 20px to sustain modern punch, while UI labels use slight positive tracking for crisp glanceability on OLED screens.

## Layout & Spacing

The layout operates on a mobile-first, 4-column fluid grid system pinned with safe area awareness for edge-to-edge iOS and Android displays. 

- **Outer Margin**: `1.25rem` (20px) on native portrait viewports ensures maximum touch-safe breathing room while preserving horizontal reading area for cards.
- **Column Gutter**: `1rem` (16px) controls distance between grid-bound cards and dual-column memory query split-views.
- **Rhythm**: Component spacing strictly adheres to an 8pt base grid with a 4pt micro-step (`space-xs`). Tight metadata groupings use `space-sm` (8px), while memory card internals use `space-md` (16px) to maintain scannable information density.

## Elevation & Depth

Visual hierarchy uses a refined glassmorphic tiered structure combined with atmospheric neon radiance rather than heavy murky drop-shadows.

1. **Base Surface (Level 0)**: `#0a0e17` deep background with low-opacity ambient cyan/violet radial glows (blur: 80px) anchored in the corners to create spatial depth.
2. **Glass Container (Level 1)**: Translucent surface `#111726` rendered at `75%` opacity with `backdrop-filter: blur(20px)` and a 1px perimeter border tinted with `rgba(255, 255, 255, 0.08)`.
3. **Floating Interactive (Level 2)**: Elevated modals, query bars, and floating action prompts sit on `#182238` at `85%` opacity, paired with an ambient cyan-infused shadow: `0 12px 32px -4px rgba(0, 240, 255, 0.12)`.
4. **Active Focus & Accent (Level 3)**: Active input fields and AI synthesis highlights receive an internal rim glow `inset 0 0 12px rgba(0, 240, 255, 0.18)` and an external dynamic pulse.

## Shapes

The design system employs **Rounded (Level 2)** geometry:
- Standard elements (interactive cards, input fields, and bottom sheet containers) default to `1rem` (16px) corner radiuses.
- Micro-elements such as chips, status indicators, and pill tags scale down to `0.5rem` (8px) or fully rounded circular hulls (`9999px`) for contextual badges.
- Prominent feature memory cards and primary modal surfaces scale up to `1.5rem` (24px) to accentuate the friendly, handheld feel of the mobile application.

## Components

### Buttons
- **Primary Recall Action**: Solid electric cyan background (`#00f0ff`) with deep obsidian text (`#0a0e17`), 16px border-radius, `font-weight: 600`. Emits a faint 12px cyan blur on press states.
- **Secondary Glass Action**: Frosted surface with `1px rgba(0, 240, 255, 0.3)` border and white text. Provides tactile haptic feedback on touch down.
- **Ghost/Tertiary**: Text-only using cyan or slate, reserved for inline dismissals and secondary drill-downs.

### Memory Cards
- Backed with 16px or 24px border radius glass surfaces (`rgba(17, 23, 38, 0.75)`).
- Top edge hairline highlight (`1px linear-gradient(90deg, rgba(0,240,255,0.4), rgba(255,255,255,0.05))`).
- Interior content includes a category tag, contextual memory snippet, relative time delta (e.g., "Recalled 2h ago"), and an optional AI synthesis badge.

### Search & Recall Bar (Floating Input)
- Fixed or dock-pinned bottom-floating bar enabling continuous one-thumb retrieval.
- Frosted glass capsule shape with an illuminated cyan microphone/voice recall icon and integrated placeholder text ("Ask or recall anything...").

### Chips & Topic Filters
- Pill-shaped (`rounded-full`) containers with `0.5rem` horizontal padding.
- Inactive: dark translucent fill with muted text.
- Active: electric cyan border, subtle cyan background tint (`rgba(0, 240, 255, 0.12)`), and bright white label.

### Form Inputs & Checkboxes
- **Inputs**: Dark inset containers (`#0f1523`) with subtle 1px border. On focus, transitions cleanly to active cyan border with a delicate ambient bloom.
- **Checkboxes & Knowledge Nodes**: Circular selection nodes with micro-spring animations. Selected state features solid cyan fill with an obsidian checkmark.

### Retention & Memory Strength Meters
- Segmented linear bars or circular orbital rings featuring glowing cyan-to-mint gradients representing neural retention percentage and spaced-repetition schedules.