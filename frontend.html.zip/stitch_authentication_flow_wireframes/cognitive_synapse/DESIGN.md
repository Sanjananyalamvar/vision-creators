---
name: Cognitive Synapse
colors:
  surface: '#0f131d'
  surface-dim: '#0f131d'
  surface-bright: '#353944'
  surface-container-lowest: '#0a0e18'
  surface-container-low: '#171b26'
  surface-container: '#1c1f2a'
  surface-container-high: '#262a35'
  surface-container-highest: '#313540'
  on-surface: '#dfe2f1'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dfe2f1'
  inverse-on-surface: '#2c303b'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#edeaff'
  on-tertiary: '#1000a9'
  tertiary-container: '#ccccff'
  on-tertiary-container: '#4344d1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#0f131d'
  on-background: '#dfe2f1'
  surface-variant: '#313540'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-code:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style
The design system delivers an intelligent, focused, and hyper-modern environment engineered for high-performance knowledge workers, researchers, and lifelong learners. The aesthetic channels a high-clarity cognitive workspace: dark, immersive midnight indigo foundations offset by surgical electric cyan bioluminescent accents that denote activated recall, neural associations, and progressive memory retention.

The aesthetic fuses **Precision Minimalism** with **Subtle Cybernetic Glassmorphism**. UI surfaces avoid visual clutter, relying instead on tonal surface layering, ultra-crisp hairline borders, and localized luminescence. The emotional tone is calm, razor-sharp, and augmentative—making complex memory structures, active recall streams, and spaced repetition analytics feel tangible, frictionless, and effortless to master.

## Colors
The palette is built on deep cosmic midnight slate tones paired with electric cognitive cyan accents:

- **Primary (`#00E5FF`):** Electric Cyan represents activated memory states, focused synthesis, primary CTA triggers, and active recall cues.
- **Secondary (`#38BDF8`):** Sky Cyan serves as a supporting accent for semantic tags, secondary retention tiers, and interactive hover rings.
- **Tertiary (`#6366F1`):** Neural Indigo provides depth for long-term memory milestones, background neural net graphics, and secondary categorical flags.
- **Neutral Foundation (`#0B0F19` canvas / `#131B2E` surface / `#1E293B` elevated containers):** Provides contrast and sustained visual endurance during prolonged review sessions.
- **Text & Contrast Tiers:** Pure `#F8FAFC` handles primary headings and active recall content; `#94A3B8` handles contextual secondary metadata; `#475569` handles subtle borders and tertiary timestamps.

## Typography
The system balances structural geometric authority with dense data legibility:
- **Headings (Plus Jakarta Sans):** Delivers clean geometry, crisp modern kerning, and soft optical balance across onboarding titles, card headlines, and metric values.
- **Body Text (Inter):** Highly legible across multiple sentence structures, ensuring zero fatigue during deep synthesis, flashcard reviews, and transcript ingestion.
- **Metadata & Indicators (JetBrains Mono):** Monospaced precision is reserved for memory intervals (e.g. `24d`, `Next: 4h`), confidence scores, key shortcuts, and algorithm metrics.

## Layout & Spacing
A fluid 12-column responsive grid underpins wide dashboard screens, scaling dynamically to 8 columns on tablet viewports and 4 columns on mobile canvases. 

- **Structure & Gaps:** Column layouts leverage uniform `1.5rem` (`gutter`) gaps, tightening to `1rem` (`gutter-sm`) on handheld devices.
- **Container Boundaries:** Section containers maintain generous outer canvas margins of `2rem` on desktop and `1rem` on mobile screens to preserve breathing room around active memory clusters.
- **Vertical Rhythm:** Information groupings within cards adhere strictly to `0.5rem` (tight tags, metadata) or `1rem` (title to description gaps) spacings, while modular dashboard widgets maintain `1.5rem` to `2rem` element separation.

## Elevation & Depth
Depth is created through dark tonal layering combined with focused ambient cyan bioluminescence:

- **Base Layer (Level 0):** Canvas floor painted in deepest `#0B0F19`. Zero shadow, flat structural baseline.
- **Surface Layer (Level 1):** Primary dashboard cards and passive knowledge buckets in `#131B2E` with a hairline `1px` border of `rgba(255, 255, 255, 0.06)`.
- **Raised Interactive Layer (Level 2):** Hovered cards, modal panels, and active spaced repetition flashcards in `#1E293B`, framed with a `1px` translucent edge of `rgba(0, 229, 255, 0.25)` and an ambient diffuse glow: `0 12px 32px -8px rgba(0, 229, 255, 0.12)`.
- **Top / System Overlay (Level 3):** Dropdown selectors, spotlight command palettes (`Cmd+K`), and floating action bars use subtle backdrop-filter blur (`16px`) backed by `rgba(19, 27, 46, 0.85)` with a delicate outer shadow: `0 20px 48px rgba(0, 0, 0, 0.6)`.

## Shapes
The shape language uses moderate roundedness (`0.5rem` base, scaling to `1rem` on prominent cards and modals) to balance technical precision with organic accessibility.

- **Micro Inputs & Buttons:** Feature standard `0.5rem` radii (`rounded-md`), providing stable click and touch affordances.
- **Flashcards & Knowledge Containers:** Utilize `1rem` corner radii (`rounded-lg`), delivering clean definition without looking blocky.
- **Pill Badges & Filter Chips:** Employ fully rounded pill geometries (`9999px`) to distinguish categorical metadata and status flags from actionable rectangular cards.

## Components

### Buttons
- **Primary Action (Recall / Confirm):** Solid `#00E5FF` fill with `#0B0F19` bold typography. Subtle `box-shadow: 0 0 16px rgba(0, 229, 255, 0.35)`. On hover, brightness transitions with an expanded cyan aura.
- **Secondary (Ghost / Context):** `#1E293B` background with `1px` border in `rgba(255, 255, 255, 0.12)` and `#F8FAFC` label. On hover, border shifts to `rgba(0, 229, 255, 0.4)` with cyan text shift.
- **Tertiary (Subtle):** Transparent fill, muted `#94A3B8` text, transitioning to white text on hover.

### Spaced Repetition Flashcards & Knowledge Blocks
- Engineered with a high-contrast `#131B2E` container, `1rem` corner radii, and a distinct top accent strip denoting the memory retention score (gradient cyan-to-indigo).
- Reveal states feature smooth 3D axis-flip transitions or instant semantic expansion with crisp `#F8FAFC` recall prompts.

### Form Inputs & Recall Prompt Fields
- `#0B0F19` recessed interior, `0.5rem` radius, encased in a low-contrast border of `rgba(255, 255, 255, 0.1)`.
- **Active Focus State:** Border illuminates with `#00E5FF` accompanied by a soft `0 0 0 3px rgba(0, 229, 255, 0.18)` glow ring.

### Chips & Retention Tags
- Compact pill-shaped metadata pills with monospaced retention indicators (e.g., `98% Retention`, `Interval: 3d`).
- Cyan-tinted backgrounds `rgba(0, 229, 255, 0.08)` paired with `#00E5FF` typography and hairline borders.

### Checkboxes, Radios & Interval Selectors
- Custom square (`0.25rem` radius) or circular elements in `#0B0F19` with a subtle outline.
- Checked status fills with electric cyan displaying a high-contrast dark indigo checkmark icon.

### Neural Memory Strength Indicators
- Segmented linear micro-bars or circular progress rings highlighting the forgetting curve index. 
- High retention displays solid `#00E5FF`; fading memories taper into deep indigo and muted slate, prompting immediate active recall review.