from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import Base, engine
from .routers import auth, dashboard, decks, intelligence, memories, procurement, review, vendors, workspace


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)  # use Alembic migrations in production
    yield


app = FastAPI(title="Recall API", version="1.0.0", lifespan=lifespan,
              description="Backend for the Recall / ProcureMind frontend: auth, memories, spaced repetition, "
                          "knowledge intelligence, team workspaces, vendor integrations and procurement.")
app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=False,
                   allow_methods=["*"], allow_headers=["*"])

for r in (auth, dashboard, memories, decks, review, intelligence, workspace, vendors, procurement):
    app.include_router(r.router, prefix="/api/v1")


@app.get("/health", tags=["meta"])
def health():
    return {"status": "ok"}
