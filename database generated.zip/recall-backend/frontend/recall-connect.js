/* Recall prototype connector: wires the Stitch screens to the FastAPI backend. */
(() => {
  const API = window.RECALL_API || "/api/v1";
  const PAGE = document.currentScript.dataset.page;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const store = () => localStorage.getItem("rc_token") ? localStorage : sessionStorage;

  async function api(path, opts = {}) {
    const token = localStorage.getItem("rc_token") || sessionStorage.getItem("rc_token");
    const res = await fetch(API + path, {
      method: opts.method || "GET",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: "Bearer " + token } : {}) },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
    });
    if (res.status === 401 && !["login", "signup"].includes(PAGE)) { logout(); throw new Error("Session expired"); }
    if (res.status === 204) return null;
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : "Please check your input");
    return data;
  }
  function logout() { localStorage.removeItem("rc_token"); sessionStorage.removeItem("rc_token"); location.href = "login.html"; }
  function toast(msg, bad) {
    const t = document.createElement("div");
    t.textContent = msg;
    t.style.cssText = `position:fixed;left:50%;top:16px;transform:translateX(-50%);z-index:9999;padding:10px 16px;border-radius:10px;
      font:600 13px system-ui;color:#fff;background:${bad ? "#b3261e" : "#0b6b73"};box-shadow:0 4px 20px #0008`;
    document.body.appendChild(t); setTimeout(() => t.remove(), 3000);
  }
  // set text of the first leaf element whose text matches a regex
  function setLeaf(re, value, root = document) {
    const el = $$("span,p,div,h1,h2,h3", root).find(e => !e.children.length && re.test(e.textContent));
    if (el) el.textContent = value; return el;
  }
  const guard = fn => async (...a) => { try { return await fn(...a); } catch (e) { toast(e.message, true); } };
  const ago = iso => { if (!iso) return "never reviewed"; const m = (Date.now() - new Date(iso + "Z")) / 6e4;
    return m < 60 ? Math.round(m) + "m ago" : m < 1440 ? Math.round(m / 60) + "h ago" : Math.round(m / 1440) + "d ago"; };

  // ---------- nav (all app pages) ----------
  const ROUTES = { "home-dashboard": "dashboard.html", "recall-review": "review.html", "search-explore": "stream.html",
                   recall: "stream.html", "profile": "dashboard.html", "profile-settings": "dashboard.html" };
  $$("[data-path]").forEach(a => { const to = ROUTES[a.dataset.path]; if (to) a.setAttribute("href", to); });
  if (!["login", "signup"].includes(PAGE) && !(localStorage.getItem("rc_token") || sessionStorage.getItem("rc_token")))
    location.href = "login.html";

  // ---------- login ----------
  if (PAGE === "login") {
    const btn = $$("button").find(b => /log in to recall/i.test(b.textContent));
    const go = guard(async () => {
      const remember = $("#remember-me")?.checked;
      const r = await api("/auth/login", { method: "POST", body: { identifier: $("#email").value, password: $("#password").value, remember_me: !!remember } });
      (remember ? localStorage : sessionStorage).setItem("rc_token", r.access_token);
      location.href = "dashboard.html";
    });
    btn?.addEventListener("click", go);
    [$("#email"), $("#password")].forEach(i => i?.addEventListener("keydown", e => e.key === "Enter" && go()));
    $$("a").filter(a => a.getAttribute("href") === "#signup").forEach(a => a.setAttribute("href", "signup.html"));
    $$("button").filter(b => /google|apple|github/i.test(b.textContent)).forEach(b =>
      b.addEventListener("click", guard(() => api("/auth/oauth/" + b.textContent.trim().toLowerCase().split(/\s+/).pop(), { method: "POST" }))));
    $("#biometric-trigger")?.addEventListener("click", guard(() => api("/auth/oauth/passkey", { method: "POST" })));
  }

  // ---------- signup ----------
  if (PAGE === "signup") {
    $("#signup-form")?.addEventListener("submit", guard(async e => {
      e.preventDefault();
      const r = await api("/auth/signup", { method: "POST", body: { full_name: $("#name-input").value, email: $("#email-input").value, password: $("#password-input").value } });
      sessionStorage.setItem("rc_token", r.access_token);
      location.href = "dashboard.html";
    }));
    $$("a").filter(a => /log in|sign in/i.test(a.textContent)).forEach(a => a.setAttribute("href", "login.html"));
  }

  // ---------- dashboard ----------
  if (PAGE === "dashboard") {
    guard(async () => {
      const d = await api("/dashboard");
      const h1 = $("h1"); if (h1?.firstChild) h1.firstChild.textContent = `Hello ${d.greeting_name}, `;
      setLeaf(/memory pathways/i, `${d.queue.due} memory pathways primed for review.`);
      setLeaf(/\bcards\b/i, `${d.queue.due} cards`);
      setLeaf(/mins/i, `~${d.queue.estimated_minutes} mins`);
      setLeaf(/^\d+%$/, Math.round((d.retention.average ?? 0) * 100) + "%");
      const circ = $$("svg circle")[1]; if (circ) circ.setAttribute("stroke-dashoffset", 119.38 * (1 - (d.retention.average ?? 0)));
      const start = $("#start-session-btn");
      if (start) { start.lastElementChild.textContent = `Start Review (${d.queue.estimated_minutes} min)`;
        start.disabled = !d.queue.due; start.addEventListener("click", () => location.href = "review.html"); }
      $("#quick-capture-input")?.addEventListener("keydown", guard(async e => {
        if (e.key !== "Enter" || !e.target.value.trim()) return;
        await api("/memories", { method: "POST", body: { content: e.target.value, partition: "work" } });
        e.target.value = ""; toast("Memory captured"); setTimeout(() => location.reload(), 700);
      }));
    })();
  }

  // ---------- review ----------
  if (PAGE === "review") {
    guard(async () => {
      const s = await api("/review/sessions", { method: "POST", body: { limit: 20 } }).catch(e => { toast(e.message); return null; });
      if (!s) return;
      const dash = await api("/dashboard");
      let i = 0, shownAt = Date.now();
      const bar = $('[style*="width"]'), grades = $$(".grade-btn"), G = ["again", "hard", "good", "easy"];
      const render = () => {
        const c = s.cards[i]; shownAt = Date.now();
        if (!c) return finish();
        const prompt = $("#card-prompt p"); if (prompt) prompt.textContent = c.question;
        const ans = $("#card-answer"); ans.replaceChildren(Object.assign(document.createElement("p"), { textContent: c.answer, className: "text-lg text-white p-4" }));
        const hb = $("#hint-box span:last-child"); if (hb) hb.textContent = c.hint || "No hint for this card.";
        setLeaf(/^SYNAPSE #/, `SYNAPSE #${String(c.id).padStart(4, "0")}`);
        setLeaf(/^Streak:/, `Streak: ${dash.streak_days} days`);
        if (bar) bar.style.width = (100 * i / s.cards.length) + "%";
        grades.forEach((b, k) => { const l = b.querySelectorAll("span"); if (l[1]) l[1].textContent = c.intervals[G[k]] ?? l[1].textContent; });
      };
      grades.forEach((b, k) => b.addEventListener("click", guard(async () => {
        const c = s.cards[i]; if (!c) return;
        await api(`/review/sessions/${s.session_id}/answer`, { method: "POST", body: { memory_id: c.id, grade: G[k], response_ms: Date.now() - shownAt } });
        i++; setTimeout(render, 380);
      })));
      const finish = guard(async () => {
        const r = await api(`/review/sessions/${s.session_id}/finish`, { method: "POST" });
        if (bar) bar.style.width = "100%";
        toast(`Session done: ${r.reviewed} cards, ${Math.round((r.accuracy ?? 0) * 100)}% recalled`);
        setTimeout(() => location.href = "dashboard.html", 1800);
      });
      render();
    })();
  }

  // ---------- memory stream ----------
  if (PAGE === "stream") {
    const del = $$('button[aria-label="Delete Memory"]');
    const card = del.length && del[0].closest("div:has(h3)");
    const parent = card?.parentElement, tpl = card?.cloneNode(true);
    $$('button[aria-label="Delete Memory"]', parent).length && $$(":scope > div", parent).filter(d => d.querySelector("h3")).forEach(d => d.remove());
    const load = guard(async (q = "") => {
      const r = await api("/memories?limit=30" + (q ? "&q=" + encodeURIComponent(q) : ""));
      $$(":scope > [data-mem]", parent).forEach(n => n.remove());
      r.items.forEach(m => {
        const n = tpl.cloneNode(true); n.dataset.mem = m.id;
        $("h3", n).textContent = m.title;
        const ps = $$("p", n); ps[0].textContent = `Recalled ${m.recall_count} times • ${ago(m.last_reviewed_at)}`;
        ps[1].textContent = m.content;
        const sim = $$("span", n).find(s => /similarity/.test(s.textContent)); if (sim) sim.textContent = m.similarity != null ? m.similarity.toFixed(2) + " similarity" : (m.strength || "new");
        const tagBox = $$("span", n).find(s => s.textContent.startsWith("#"))?.parentElement;
        if (tagBox) { const t = tagBox.firstElementChild; tagBox.replaceChildren(...(m.tags.length ? m.tags : [m.partition]).map(x => { const c = t.cloneNode(); c.textContent = "#" + x; return c; })); }
        $('button[aria-label="Delete Memory"]', n)?.addEventListener("click", guard(async () => { await api("/memories/" + m.id, { method: "DELETE" }); n.remove(); toast("Memory purged"); }));
        $('button[aria-label="Verify Memory"]', n)?.addEventListener("click", guard(async () => { await api("/memories/" + m.id, { method: "PATCH", body: { pinned: !m.pinned } }); m.pinned = !m.pinned; toast(m.pinned ? "Verified & pinned" : "Unpinned"); }));
        $('button[aria-label="Edit Memory"]', n)?.addEventListener("click", guard(async () => { const v = prompt("Edit memory", m.content); if (v) { await api("/memories/" + m.id, { method: "PATCH", body: { content: v } }); load($("#mem-query-input").value); } }));
        parent.appendChild(n);
      });
      if (!r.items.length) toast("No memories found");
    });
    load();
    const qi = $("#mem-query-input");
    qi?.addEventListener("keydown", e => e.key === "Enter" && load(qi.value.trim()));
    $('button[aria-label="Perform AI Recall"]')?.addEventListener("click", () => load(qi.value.trim()));
    const ta = $("textarea");
    ta?.addEventListener("keydown", guard(async e => {
      if (e.key !== "Enter" || e.shiftKey || !ta.value.trim()) return; e.preventDefault();
      await api("/memories", { method: "POST", body: { content: ta.value, partition: "work" } }); ta.value = ""; toast("Memory stored"); load();
    }));
  }
})();
