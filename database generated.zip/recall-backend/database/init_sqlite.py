"""Creates recall.db from schema.sqlite.sql and loads demo data (stdlib only, no server needed).
Usage: python database/init_sqlite.py [--reset] [--no-seed]"""
import base64, hashlib, json, os, pathlib, sqlite3, sys
from datetime import datetime, timedelta, timezone

ROOT = pathlib.Path(__file__).resolve().parent
DB = pathlib.Path(os.getenv("DATABASE_URL", "sqlite:///./recall.db").removeprefix("sqlite:///"))
DB = DB if DB.is_absolute() else ROOT.parent / DB
if "--reset" in sys.argv:
    DB.unlink(missing_ok=True)

def hash_password(pw):  # identical format to app/security.py
    salt = os.urandom(16)
    dk = hashlib.scrypt(pw.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"

now = datetime.now(timezone.utc).replace(tzinfo=None)
ts = lambda dt: dt.strftime("%Y-%m-%d %H:%M:%S.%f")
con = sqlite3.connect(DB)
con.execute("PRAGMA foreign_keys = ON")
if con.execute("SELECT name FROM sqlite_master WHERE name='users'").fetchone():
    sys.exit(f"{DB.name} already has tables; use --reset to rebuild.")
con.executescript((ROOT / "schema.sqlite.sql").read_text())
print("schema created in", DB)
if "--no-seed" in sys.argv:
    sys.exit(con.commit() or 0)

q = lambda sql, *a: con.execute(sql, a).lastrowid
uid = q("INSERT INTO users(email,handle,full_name,title,password_hash) VALUES (?,?,?,?,?)",
        "alex@company.com", "alex", "Alex Vance", "Product Engineer", hash_password("RecallMemoryPass2025"))
ws = q("INSERT INTO workspaces(name,code,owner_id) VALUES (?,?,?)", "Alex's Workspace", "WS-0x4A1E", uid)
q("INSERT INTO memberships(workspace_id,user_id,role,partitions) VALUES (?,?,?,?)", ws, uid, "owner", json.dumps(["personal", "work"]))
q("INSERT INTO cost_centers(workspace_id,code,name,quarterly_budget) VALUES (?,?,?,?)", ws, "CC-GENERAL-001", "General", 12500)
decks = {n: q("INSERT INTO decks(workspace_id,owner_id,name,icon) VALUES (?,?,?,?)", ws, uid, n, i)
         for n, i in [("Inbox", "inbox"), ("Distributed Systems", "hub"), ("Engineering", "code")]}

# (title, question, answer, hint, tags, deck, partition, interval_days, reviewed_days_ago)
CARDS = [
 ("CAP Theorem", "What is the CAP Theorem, and how does Apache Cassandra handle network partitions?",
  "A distributed store can't guarantee Consistency, Availability and Partition tolerance together. Cassandra is AP: it stays available and offers tunable consistency (W + R > N).",
  "Think tunable consistency and quorum calculations.", ["distributed-systems"], "Distributed Systems", "work", 0, None),
 ("pgvector vs dedicated vector DB", "Why choose pgvector over a dedicated vector DB?",
  "Embeddings live next to relational data, one system to operate, good enough up to a few million vectors.",
  None, ["engineering", "vector-db"], "Engineering", "work", 4, 5),
 ("Dietary preferences", "Alex's dietary preferences?", "Prefers oat milk lattes, allergic to shellfish. Flying SFO to NYC on Thursday.",
  None, ["personal", "preferences"], "Inbox", "personal", 10, 3),
 ("Raft leader election", "How does Raft elect a leader?",
  "Followers time out, become candidates, request votes; a majority vote wins the term.", None, ["distributed-systems"], "Distributed Systems", "work", 1, 2),
 ("Idempotency keys", "Why do payment APIs use idempotency keys?",
  "So a retried request is applied once, preventing duplicate charges.", "Retries + network failures.", ["engineering", "api"], "Engineering", "work", 21, 9),
 ("SM-2 spaced repetition", "What does the SM-2 ease factor control?",
  "How fast the review interval grows after each successful recall.", None, ["learning"], "Inbox", "personal", 0, None),
]
mem_ids = []
for t, qn, a, h, tags, deck, part, iv, ago in CARDS:
    last = now - timedelta(days=ago) if ago is not None else None
    due = (last + timedelta(days=iv)) if last else now
    mem_ids.append(q("""INSERT INTO memories(workspace_id,owner_id,deck_id,title,content,question,answer,hint,source,tags,partition,
                        interval_days,repetitions,recall_count,due_at,last_reviewed_at,created_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        ws, uid, decks[deck], t, a, qn, a, h, "manual", json.dumps(tags), part, iv, 1 if last else 0, 1 if last else 0,
        ts(due), ts(last) if last else None, ts(now - timedelta(days=(ago or 0) + 1))))

# one review per day for the last 4 days so the dashboard streak/stats are non-empty
for d in range(4):
    when = now - timedelta(days=d, hours=1)
    sid = q("INSERT INTO review_sessions(workspace_id,user_id,card_ids,started_at,ended_at) VALUES (?,?,?,?,?)",
            ws, uid, json.dumps(mem_ids[1:3]), ts(when), ts(when + timedelta(minutes=2)))
    for m in mem_ids[1:3]:
        q("""INSERT INTO review_logs(workspace_id,user_id,memory_id,session_id,grade,correct,response_ms,interval_before,interval_after,reviewed_at)
             VALUES (?,?,?,?,?,?,?,?,?,?)""", ws, uid, m, sid, "good", 1, 3200, 1, 4, ts(when))
con.commit()
print("seeded: login alex@company.com / RecallMemoryPass2025  (6 cards, 3 decks, 4-day streak)")
