"""Generates schema.sqlite.sql and schema.postgres.sql from schema.template.sql."""
import pathlib
here = pathlib.Path(__file__).parent
tpl = (here / "schema.template.sql").read_text()
D = {
  "sqlite":   {"PK": "INTEGER PRIMARY KEY AUTOINCREMENT", "TS": "DATETIME", "JSON": "JSON", "BOOL": "BOOLEAN", "FLOAT": "FLOAT", "F": "0", "T": "1"},
  "postgres": {"PK": "SERIAL PRIMARY KEY", "TS": "TIMESTAMP", "JSON": "JSON", "BOOL": "BOOLEAN", "FLOAT": "DOUBLE PRECISION", "F": "FALSE", "T": "TRUE"},
}
for name, m in D.items():
    out = tpl
    for k, v in m.items():
        out = out.replace("{" + k + "}", v)
    (here / f"schema.{name}.sql").write_text(out)
    print("wrote", f"schema.{name}.sql")
