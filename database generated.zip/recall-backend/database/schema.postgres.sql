-- Recall database schema (mirrors app/models.py). Tokens are filled by build_schema.py per dialect.
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) NOT NULL UNIQUE,
  handle VARCHAR(64) UNIQUE,
  full_name VARCHAR(120) NOT NULL,
  title VARCHAR(120),
  avatar_url VARCHAR(500),
  password_hash VARCHAR(255) NOT NULL,
  reset_token_hash VARCHAR(64),
  reset_expires TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_users_email ON users(email);

CREATE TABLE workspaces (
  id SERIAL PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  code VARCHAR(32) NOT NULL UNIQUE,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  seat_limit INTEGER NOT NULL DEFAULT 8,
  settings JSON NOT NULL DEFAULT '{"isolate_personal_work": true, "redact_multi_user": true, "audit_replay": false}',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE memberships (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role VARCHAR(16) NOT NULL DEFAULT 'member' CHECK (role IN ('owner','admin','member','read_only','auditor')),
  partitions JSON NOT NULL DEFAULT '[]',
  last_active_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (workspace_id, user_id)
);
CREATE INDEX ix_memberships_workspace_id ON memberships(workspace_id);
CREATE INDEX ix_memberships_user_id ON memberships(user_id);

CREATE TABLE invitations (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  email VARCHAR(255) NOT NULL,
  role VARCHAR(16) NOT NULL DEFAULT 'member' CHECK (role IN ('owner','admin','member','read_only','auditor')),
  partitions JSON NOT NULL DEFAULT '[]',
  invited_by INTEGER NOT NULL REFERENCES users(id),
  status VARCHAR(16) NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_invitations_workspace_id ON invitations(workspace_id);
CREATE INDEX ix_invitations_email ON invitations(email);

CREATE TABLE api_keys (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  created_by INTEGER NOT NULL REFERENCES users(id),
  name VARCHAR(80) NOT NULL,
  prefix VARCHAR(12) NOT NULL,
  key_hash VARCHAR(64) NOT NULL UNIQUE,
  revoked BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_used_at TIMESTAMP
);
CREATE INDEX ix_api_keys_workspace_id ON api_keys(workspace_id);
CREATE INDEX ix_api_keys_key_hash ON api_keys(key_hash);

CREATE TABLE audit_logs (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  actor_id INTEGER REFERENCES users(id),
  action VARCHAR(64) NOT NULL,
  target VARCHAR(120),
  meta JSON NOT NULL DEFAULT '{}',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_audit_logs_workspace_id ON audit_logs(workspace_id);
CREATE INDEX ix_audit_logs_created_at ON audit_logs(created_at);

CREATE TABLE decks (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  name VARCHAR(120) NOT NULL,
  icon VARCHAR(40) NOT NULL DEFAULT 'layers',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_decks_workspace_id ON decks(workspace_id);

-- A memory / flashcard. question+answer drive review; content is the raw capture.
CREATE TABLE memories (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  deck_id INTEGER REFERENCES decks(id) ON DELETE SET NULL,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL DEFAULT '',
  question TEXT NOT NULL DEFAULT '',
  answer TEXT NOT NULL DEFAULT '',
  hint TEXT,
  url VARCHAR(1000),
  source VARCHAR(40) NOT NULL DEFAULT 'manual',
  tags JSON NOT NULL DEFAULT '[]',
  partition VARCHAR(64) NOT NULL DEFAULT 'personal',
  pinned BOOLEAN NOT NULL DEFAULT FALSE,
  archived BOOLEAN NOT NULL DEFAULT FALSE,
  ease DOUBLE PRECISION NOT NULL DEFAULT 2.5,
  interval_days DOUBLE PRECISION NOT NULL DEFAULT 0,
  repetitions INTEGER NOT NULL DEFAULT 0,
  lapses INTEGER NOT NULL DEFAULT 0,
  recall_count INTEGER NOT NULL DEFAULT 0,
  due_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_reviewed_at TIMESTAMP,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_memories_workspace_id ON memories(workspace_id);
CREATE INDEX ix_memories_owner_id ON memories(owner_id);
CREATE INDEX ix_memories_deck_id ON memories(deck_id);
CREATE INDEX ix_memories_due_at ON memories(due_at);
-- review queue: live (non-archived) cards per workspace ordered by due date
CREATE INDEX ix_memories_queue ON memories(workspace_id, due_at) WHERE archived = FALSE;

CREATE TABLE review_sessions (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  deck_id INTEGER REFERENCES decks(id) ON DELETE SET NULL,
  card_ids JSON NOT NULL DEFAULT '[]',
  started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ended_at TIMESTAMP
);
CREATE INDEX ix_review_sessions_workspace_id ON review_sessions(workspace_id);
CREATE INDEX ix_review_sessions_user_id ON review_sessions(user_id);

CREATE TABLE review_logs (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  memory_id INTEGER NOT NULL REFERENCES memories(id),
  session_id INTEGER REFERENCES review_sessions(id) ON DELETE SET NULL,
  grade VARCHAR(8) NOT NULL CHECK (grade IN ('again','hard','good','easy')),
  correct BOOLEAN NOT NULL,
  response_ms INTEGER,
  interval_before DOUBLE PRECISION NOT NULL DEFAULT 0,
  interval_after DOUBLE PRECISION NOT NULL DEFAULT 0,
  reviewed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_review_logs_workspace_id ON review_logs(workspace_id);
CREATE INDEX ix_review_logs_user_id ON review_logs(user_id);
CREATE INDEX ix_review_logs_memory_id ON review_logs(memory_id);
CREATE INDEX ix_review_logs_reviewed_at ON review_logs(reviewed_at);

CREATE TABLE contradictions (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  memory_a_id INTEGER NOT NULL REFERENCES memories(id),
  memory_b_id INTEGER NOT NULL REFERENCES memories(id),
  statement_a TEXT NOT NULL,
  statement_b TEXT NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'open' CHECK (status IN ('open','resolved','dismissed')),
  resolution VARCHAR(16),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX ix_contradictions_workspace_id ON contradictions(workspace_id);

CREATE TABLE vendor_connections (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  vendor_key VARCHAR(40) NOT NULL,
  category VARCHAR(20) NOT NULL,
  pipeline_id VARCHAR(80),
  secret_encrypted TEXT,             -- Fernet ciphertext, never returned by the API
  region VARCHAR(40),
  embed_dim INTEGER,
  index_partition VARCHAR(80),
  realtime_ingestion BOOLEAN NOT NULL DEFAULT TRUE,
  zero_knowledge BOOLEAN NOT NULL DEFAULT FALSE,
  budget_limit DOUBLE PRECISION NOT NULL DEFAULT 50,
  status VARCHAR(16) NOT NULL DEFAULT 'staging' CHECK (status IN ('staging','connected','error')),
  latency_ms INTEGER,
  quota_used DOUBLE PRECISION NOT NULL DEFAULT 0,
  vector_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_synced_at TIMESTAMP
);
CREATE INDEX ix_vendor_connections_workspace_id ON vendor_connections(workspace_id);

CREATE TABLE cost_centers (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  code VARCHAR(40) NOT NULL,
  name VARCHAR(120) NOT NULL,
  quarterly_budget DOUBLE PRECISION NOT NULL DEFAULT 12500,
  spent DOUBLE PRECISION NOT NULL DEFAULT 0,
  UNIQUE (workspace_id, code)
);
CREATE INDEX ix_cost_centers_workspace_id ON cost_centers(workspace_id);

CREATE TABLE purchase_orders (
  id SERIAL PRIMARY KEY,
  workspace_id INTEGER NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  number VARCHAR(24) NOT NULL UNIQUE,
  requested_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  vendor_key VARCHAR(40) NOT NULL,
  plan_id VARCHAR(40) NOT NULL,
  allocation VARCHAR(80) NOT NULL,
  embed_dim INTEGER,
  region VARCHAR(40),
  term VARCHAR(40) NOT NULL DEFAULT 'annual',
  billing_schedule VARCHAR(20) NOT NULL DEFAULT 'quarterly',
  payment_terms VARCHAR(20) NOT NULL DEFAULT 'net30',
  payment_method VARCHAR(80),        -- label only; never store card numbers
  line_items JSON NOT NULL DEFAULT '[]',
  subtotal DOUBLE PRECISION NOT NULL,
  discount DOUBLE PRECISION NOT NULL DEFAULT 0,
  tax DOUBLE PRECISION NOT NULL DEFAULT 0,
  total DOUBLE PRECISION NOT NULL,
  currency VARCHAR(3) NOT NULL DEFAULT 'USD',
  cost_center_id INTEGER REFERENCES cost_centers(id),
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval',
  approval_hash VARCHAR(64),
  vendor_connection_id INTEGER REFERENCES vendor_connections(id),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  approved_at TIMESTAMP,
  completed_at TIMESTAMP
);
CREATE INDEX ix_purchase_orders_workspace_id ON purchase_orders(workspace_id);

CREATE TABLE order_steps (
  id SERIAL PRIMARY KEY,
  order_id INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  key VARCHAR(40) NOT NULL,
  label VARCHAR(120) NOT NULL,
  detail VARCHAR(255),
  status VARCHAR(12) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','running','completed')),
  delay_s INTEGER NOT NULL DEFAULT 0,
  completed_at TIMESTAMP
);
CREATE INDEX ix_order_steps_order_id ON order_steps(order_id);
