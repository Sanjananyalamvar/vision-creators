import os


def _f(name, default):
    return float(os.getenv(name, default))


class Settings:
    database_url = os.getenv("DATABASE_URL", "sqlite:///./recall.db")
    jwt_secret = os.getenv("JWT_SECRET", "dev-secret-change-me")
    jwt_alg = "HS256"
    vendor_secret_key = os.getenv("VENDOR_SECRET_KEY", "")
    cors_origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]
    tax_rate = _f("TAX_RATE", 0.08)
    volume_discount = _f("VOLUME_DISCOUNT", 0.15)
    auto_approve_limit = _f("AUTO_APPROVE_LIMIT", 5000)
    provisioning_simulation = os.getenv("PROVISIONING_SIMULATION", "true").lower() == "true"
    session_hours = 24
    remember_me_days = 30


settings = Settings()
