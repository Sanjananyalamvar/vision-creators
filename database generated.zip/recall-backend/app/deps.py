from dataclasses import dataclass

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import false, or_, select
from sqlalchemy.orm import Session

from .database import get_db, utcnow
from .models import ApiKey, AuditLog, Membership, Memory, User, Workspace
from .security import decode_token, sha256

bearer = HTTPBearer(auto_error=False)
ROLES = ("owner", "admin", "member", "read_only", "auditor")


@dataclass
class Ctx:
    user: User
    ws: Workspace
    membership: Membership

    @property
    def role(self) -> str:
        return self.membership.role


def get_ctx(
    creds: HTTPAuthorizationCredentials | None = Depends(bearer),
    x_api_key: str | None = Header(default=None),
    x_workspace_id: int | None = Header(default=None),
    db: Session = Depends(get_db),
) -> Ctx:
    user = None
    forced_ws = None
    if x_api_key:
        key = db.scalar(select(ApiKey).where(ApiKey.key_hash == sha256(x_api_key), ApiKey.revoked == False))  # noqa: E712
        if key:
            key.last_used_at = utcnow()
            user, forced_ws = db.get(User, key.created_by), key.workspace_id
    elif creds:
        uid = decode_token(creds.credentials)
        user = db.get(User, uid) if uid else None
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or missing credentials",
                            headers={"WWW-Authenticate": "Bearer"})
    ws_id = forced_ws or x_workspace_id
    q = select(Membership).where(Membership.user_id == user.id)
    if ws_id:
        q = q.where(Membership.workspace_id == ws_id)
    m = db.scalars(q.order_by(Membership.id)).first()
    if not m:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "No access to this workspace")
    m.last_active_at = utcnow()
    db.commit()
    return Ctx(user, db.get(Workspace, m.workspace_id), m)


def require(*roles: str):
    def dep(ctx: Ctx = Depends(get_ctx)) -> Ctx:
        if ctx.role not in roles:
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Requires role: {', '.join(roles)}")
        return ctx
    return dep


can_write = require("owner", "admin", "member")
admin_only = require("owner", "admin")
owner_only = require("owner")


def visible_memories(ctx: Ctx):
    """Base query honouring roles, partitions and the workspace privacy settings."""
    q = select(Memory).where(Memory.workspace_id == ctx.ws.id, Memory.archived == False)  # noqa: E712
    if ctx.role == "auditor":  # auditors never see raw context
        return q.where(false())
    if ctx.ws.settings.get("isolate_personal_work", True):
        q = q.where(or_(Memory.partition != "personal", Memory.owner_id == ctx.user.id))
    if ctx.role in ("owner", "admin"):
        return q
    return q.where(or_(Memory.owner_id == ctx.user.id, Memory.partition.in_(ctx.membership.partitions or [])))


def audit(db: Session, ctx: Ctx, action: str, target: str | None = None, **meta):
    db.add(AuditLog(workspace_id=ctx.ws.id, actor_id=ctx.user.id, action=action, target=target, meta=meta))
