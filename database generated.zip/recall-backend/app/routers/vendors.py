import time
import urllib.request

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, admin_only, audit, get_ctx
from ..models import VendorConnection
from ..security import decrypt_secret, encrypt_secret, mask_secret
from ..services.catalog import VENDORS

router = APIRouter(prefix="/vendors", tags=["vendors & integrations"])


class ConnectIn(BaseModel):
    vendor_key: str
    pipeline_id: str | None = None
    api_secret: str | None = Field(default=None, repr=False)
    region: str | None = None
    embed_dim: int | None = None
    index_partition: str | None = None
    realtime_ingestion: bool = True
    zero_knowledge: bool = False
    budget_limit: float = Field(default=50.0, ge=0)
    stage_only: bool = False  # "Save as Staging Pipeline"


class ConnPatch(BaseModel):
    pipeline_id: str | None = None
    region: str | None = None
    embed_dim: int | None = None
    index_partition: str | None = None
    realtime_ingestion: bool | None = None
    zero_knowledge: bool | None = None
    budget_limit: float | None = Field(default=None, ge=0)


class UsageIn(BaseModel):
    spend: float = Field(ge=0)
    vectors_added: int = 0


def probe(vendor_key: str, timeout: float = 4.0) -> dict:
    """Reachability + RTT check against the vendor endpoint. It does NOT validate credentials —
    add a vendor-specific authenticated call here for a true 'Authenticate & Test'."""
    url = VENDORS[vendor_key]["probe_url"]
    t0 = time.perf_counter()
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "recall-backend/1.0"})
        try:
            urllib.request.urlopen(req, timeout=timeout)
        except urllib.error.HTTPError:
            pass  # any HTTP response proves the host is reachable
        return {"ok": True, "rtt_ms": round((time.perf_counter() - t0) * 1000), "tls": url.startswith("https"),
                "authenticated": False}
    except Exception as e:
        return {"ok": False, "error": str(e)[:160], "authenticated": False}


def conn_out(c: VendorConnection) -> dict:
    v = VENDORS.get(c.vendor_key, {})
    return {
        "id": c.id, "vendor_key": c.vendor_key, "name": v.get("name", c.vendor_key), "category": c.category,
        "tagline": v.get("tagline"), "status": c.status, "pipeline_id": c.pipeline_id, "region": c.region,
        "embed_dim": c.embed_dim, "index_partition": c.index_partition, "realtime_ingestion": c.realtime_ingestion,
        "zero_knowledge": c.zero_knowledge, "latency_ms": c.latency_ms,
        "spend": {"used": round(c.quota_used, 2), "limit": c.budget_limit,
                  "percent": round(100 * c.quota_used / c.budget_limit, 1) if c.budget_limit else 0},
        "vector_count": c.vector_count, "secret_hint": "configured" if c.secret_encrypted else None,
        "last_synced_at": c.last_synced_at.isoformat() if c.last_synced_at else None,
    }


@router.get("/catalog")
def catalog(category: str | None = None, q: str | None = None, ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    connected = {c.vendor_key for c in db.scalars(select(VendorConnection).where(VendorConnection.workspace_id == ctx.ws.id))}
    out = []
    for k, v in VENDORS.items():
        if category and v["category"] != category:
            continue
        if q and q.lower() not in f"{v['name']} {v['description']} {v['tagline']}".lower():
            continue
        out.append({"key": k, **{f: v[f] for f in ("name", "category", "tagline", "verified", "description", "regions", "dims")},
                    "connected": k in connected})
    return out


@router.get("/connections")
def connections(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    rows = db.scalars(select(VendorConnection).where(VendorConnection.workspace_id == ctx.ws.id).order_by(VendorConnection.id)).all()
    return [conn_out(c) for c in rows]


@router.get("/overview")
def overview(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    rows = db.scalars(select(VendorConnection).where(VendorConnection.workspace_id == ctx.ws.id)).all()
    live = [c for c in rows if c.status == "connected"]
    lat = [c.latency_ms for c in live if c.latency_ms is not None]
    total = sum(c.quota_used for c in rows)
    return {
        "connected": len(live), "total": len(rows),
        "avg_latency_ms": round(sum(lat) / len(lat)) if lat else None,
        "health": "operational" if rows and all(c.status != "error" for c in rows) else "degraded" if rows else "idle",
        "billing_cycle_spend": round(total, 2),
        "allocation": [{"vendor_key": c.vendor_key, "name": VENDORS.get(c.vendor_key, {}).get("name"),
                        "percent": round(100 * c.quota_used / total) if total else 0} for c in rows],
        "available_to_connect": [k for k in VENDORS if k not in {c.vendor_key for c in rows}],
    }


@router.post("/connections", status_code=201)
def connect(body: ConnectIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    v = VENDORS.get(body.vendor_key)
    if not v:
        raise HTTPException(404, "Unknown vendor")
    if body.region and v["regions"] and body.region not in v["regions"]:
        raise HTTPException(422, f"region must be one of {v['regions']}")
    if body.embed_dim and v["dims"] and body.embed_dim not in v["dims"]:
        raise HTTPException(422, f"embed_dim must be one of {v['dims']}")
    if db.scalar(select(VendorConnection).where(VendorConnection.workspace_id == ctx.ws.id,
                                                VendorConnection.vendor_key == body.vendor_key)):
        raise HTTPException(409, "Vendor already connected")
    c = VendorConnection(
        workspace_id=ctx.ws.id, vendor_key=body.vendor_key, category=v["category"], pipeline_id=body.pipeline_id,
        secret_encrypted=encrypt_secret(body.api_secret) if body.api_secret else None, region=body.region,
        embed_dim=body.embed_dim, index_partition=body.index_partition, realtime_ingestion=body.realtime_ingestion,
        zero_knowledge=body.zero_knowledge, budget_limit=body.budget_limit,
    )
    if body.stage_only:
        c.status = "staging"
    else:
        r = probe(body.vendor_key)
        c.status, c.latency_ms = ("connected", r.get("rtt_ms")) if r["ok"] else ("error", None)
        c.last_synced_at = utcnow() if r["ok"] else None
    db.add(c)
    audit(db, ctx, "vendor.connect", body.vendor_key, status=c.status)
    db.commit()
    return conn_out(c)


class TestIn(BaseModel):
    vendor_key: str


@router.post("/test")
def test_before_save(body: TestIn, ctx: Ctx = Depends(get_ctx)):
    """'Authenticate & Test Connection' before a connection exists."""
    if body.vendor_key not in VENDORS:
        raise HTTPException(404, "Unknown vendor")
    return probe(body.vendor_key)


def _conn(db, ctx, cid) -> VendorConnection:
    c = db.scalar(select(VendorConnection).where(VendorConnection.id == cid, VendorConnection.workspace_id == ctx.ws.id))
    if not c:
        raise HTTPException(404, "Connection not found")
    return c


@router.post("/connections/{cid}/test")
def test_connection(cid: int, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    c = _conn(db, ctx, cid)
    r = probe(c.vendor_key)
    c.status, c.latency_ms = ("connected", r.get("rtt_ms")) if r["ok"] else ("error", c.latency_ms)
    if r["ok"]:
        c.last_synced_at = utcnow()
    db.commit()
    return r


@router.patch("/connections/{cid}")
def update_connection(cid: int, body: ConnPatch, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    c = _conn(db, ctx, cid)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(c, k, v)
    audit(db, ctx, "vendor.update", c.vendor_key)
    db.commit()
    return conn_out(c)


class RotateIn(BaseModel):
    api_secret: str


@router.post("/connections/{cid}/rotate-key")
def rotate_key(cid: int, body: RotateIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    c = _conn(db, ctx, cid)
    c.secret_encrypted = encrypt_secret(body.api_secret)
    audit(db, ctx, "vendor.rotate_key", c.vendor_key)
    db.commit()
    return {"secret_hint": mask_secret(body.api_secret)}


@router.post("/connections/{cid}/usage")
def record_usage(cid: int, body: UsageIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    """Called by your ingestion/inference workers to report spend & vector volume."""
    c = _conn(db, ctx, cid)
    c.quota_used += body.spend
    c.vector_count += body.vectors_added
    c.last_synced_at = utcnow()
    db.commit()
    return conn_out(c)


@router.delete("/connections/{cid}", status_code=204)
def disconnect(cid: int, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    c = _conn(db, ctx, cid)
    audit(db, ctx, "vendor.disconnect", c.vendor_key)
    db.delete(c)
    db.commit()
