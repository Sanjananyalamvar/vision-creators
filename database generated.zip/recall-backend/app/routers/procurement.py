import secrets
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db, utcnow
from ..deps import Ctx, admin_only, audit, can_write, get_ctx
from ..models import CostCenter, OrderStep, PurchaseOrder, VendorConnection, Workspace
from ..security import sha256
from ..services.catalog import PLANS, PROVISIONING_STEPS, VENDORS
from ..services.pricing import budget_impact, build_quote

router = APIRouter(prefix="/procurement", tags=["procurement"])


class QuoteIn(BaseModel):
    vendor_key: str
    plan_id: str
    cost_center_id: int | None = None


class OrderIn(QuoteIn):
    payment_method: str | None = None  # e.g. "Corporate Card •••• 4918" (label only — never send card numbers)
    term: str = "annual"
    billing_schedule: str = "quarterly"
    payment_terms: str = "net30"
    region: str | None = None
    embed_dim: int | None = None
    save_as_draft: bool = False


class CostCenterIn(BaseModel):
    code: str = Field(min_length=2, max_length=40)
    name: str
    quarterly_budget: float = Field(gt=0)


def _plan(vendor_key, plan_id):
    p = PLANS.get((vendor_key, plan_id))
    if not p:
        raise HTTPException(404, "Unknown vendor/plan")
    return p


def _cc(db, ctx, cc_id):
    if not cc_id:
        return None
    cc = db.scalar(select(CostCenter).where(CostCenter.id == cc_id, CostCenter.workspace_id == ctx.ws.id))
    if not cc:
        raise HTTPException(404, "Cost center not found")
    return cc


def _quote(vendor_key, plan_id, cc):
    p = _plan(vendor_key, plan_id)
    q = build_quote(p["lines"], settings.volume_discount, settings.tax_rate)
    q.update({"vendor": VENDORS[vendor_key]["name"], "plan": p["label"], "allocation": p["allocation"], "currency": "USD"})
    if cc:
        q["budget_impact"] = budget_impact(cc.spent, cc.quarterly_budget, q["total"])
    q["pre_approved"] = q["total"] <= settings.auto_approve_limit and (
        not cc or q["budget_impact"]["status"] != "over_budget")
    return q


@router.get("/cost-centers")
def cost_centers(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    rows = db.scalars(select(CostCenter).where(CostCenter.workspace_id == ctx.ws.id)).all()
    return [{"id": c.id, "code": c.code, "name": c.name, "quarterly_budget": c.quarterly_budget, "spent": c.spent} for c in rows]


@router.post("/cost-centers", status_code=201)
def add_cost_center(body: CostCenterIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    if db.scalar(select(CostCenter).where(CostCenter.workspace_id == ctx.ws.id, CostCenter.code == body.code)):
        raise HTTPException(409, "Code already exists")
    c = CostCenter(workspace_id=ctx.ws.id, **body.model_dump())
    db.add(c)
    db.commit()
    return {"id": c.id, "code": c.code}


@router.post("/quote")
def quote(body: QuoteIn, ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    return _quote(body.vendor_key, body.plan_id, _cc(db, ctx, body.cost_center_id))


# ---------- orders ----------
def _approve(db: Session, o: PurchaseOrder, approver_id: int):
    now = utcnow()
    o.status, o.approved_by, o.approved_at = "provisioning", approver_id, now
    o.approval_hash = sha256(f"{o.number}|{o.total}|{approver_id}|{now.isoformat()}")
    if o.cost_center_id:
        db.get(CostCenter, o.cost_center_id).spent += o.total
    for i, (key, label, detail, delay) in enumerate(PROVISIONING_STEPS):
        db.add(OrderStep(order_id=o.id, position=i, key=key, label=label, detail=detail, delay_s=delay))


def _refresh(db: Session, o: PurchaseOrder) -> list[OrderStep]:
    steps = db.scalars(select(OrderStep).where(OrderStep.order_id == o.id).order_by(OrderStep.position)).all()
    if o.status != "provisioning":
        return steps
    now = utcnow()
    if settings.provisioning_simulation and o.approved_at:
        el = (now - o.approved_at).total_seconds()
        for s in steps:
            if s.status != "completed" and el >= s.delay_s:
                s.status, s.completed_at = "completed", o.approved_at + timedelta(seconds=s.delay_s)
    running = next((s for s in steps if s.status != "completed"), None)
    if running:
        running.status = "running"
    else:
        o.status, o.completed_at = "completed", now
        if not o.vendor_connection_id:  # order fulfilled -> the integration goes live
            c = VendorConnection(workspace_id=o.workspace_id, vendor_key=o.vendor_key,
                                 category=VENDORS[o.vendor_key]["category"], region=o.region, embed_dim=o.embed_dim,
                                 status="connected", last_synced_at=now, pipeline_id=o.number)
            db.add(c)
            db.flush()
            o.vendor_connection_id = c.id
    db.commit()
    return steps


def order_out(db: Session, o: PurchaseOrder, full=True) -> dict:
    steps = _refresh(db, o) if full else []
    n = max(1, len(steps))
    progress = 100 if o.status == "completed" else round(100 * (sum(s.status == "completed" for s in steps) +
                                                                  0.5 * sum(s.status == "running" for s in steps)) / n) if steps else 0
    out = {"id": o.id, "number": o.number, "status": o.status, "vendor": VENDORS[o.vendor_key]["name"],
           "vendor_key": o.vendor_key, "plan_id": o.plan_id, "allocation": o.allocation, "region": o.region,
           "embed_dim": o.embed_dim, "term": o.term, "billing_schedule": o.billing_schedule,
           "payment_terms": o.payment_terms, "payment_method": o.payment_method, "line_items": o.line_items,
           "subtotal": o.subtotal, "discount": o.discount, "tax": o.tax, "total": o.total, "currency": o.currency,
           "cost_center_id": o.cost_center_id, "approval_hash": o.approval_hash,
           "vendor_connection_id": o.vendor_connection_id, "created_at": o.created_at.isoformat(),
           "approved_at": o.approved_at.isoformat() if o.approved_at else None}
    if full:
        out["provisioning"] = {"progress_percent": progress, "steps": [
            {"key": s.key, "label": s.label, "detail": s.detail, "status": s.status} for s in steps]}
    return out


def _create(body: OrderIn, ctx: Ctx, db: Session) -> PurchaseOrder:
    cc = _cc(db, ctx, body.cost_center_id)
    q = _quote(body.vendor_key, body.plan_id, cc)
    p = _plan(body.vendor_key, body.plan_id)
    o = PurchaseOrder(
        workspace_id=ctx.ws.id, number=f"TMP-{secrets.token_hex(4)}", requested_by=ctx.user.id,
        vendor_key=body.vendor_key, plan_id=body.plan_id, allocation=p["allocation"], embed_dim=body.embed_dim,
        region=body.region, term=body.term, billing_schedule=body.billing_schedule, payment_terms=body.payment_terms,
        payment_method=body.payment_method, line_items=q["items"], subtotal=q["subtotal"], discount=q["discount"],
        tax=q["tax"], total=q["total"], cost_center_id=body.cost_center_id, status="draft",
    )
    db.add(o)
    db.flush()
    o.number = f"PO-{utcnow().year}-{o.id + 883:03d}"
    if not body.save_as_draft:
        _submit(db, ctx, o, q["pre_approved"])
    return o


def _submit(db, ctx, o, pre_approved: bool):
    if pre_approved:  # under the auto-approve threshold & within budget: approved under the owner's standing policy
        _approve(db, o, db.get(Workspace, ctx.ws.id).owner_id)
        audit(db, ctx, "po.auto_approved", o.number, total=o.total)
    else:
        o.status = "pending_approval"
        audit(db, ctx, "po.submitted", o.number, total=o.total)


@router.post("/orders", status_code=201)
def place_order(body: OrderIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    o = _create(body, ctx, db)
    db.commit()
    return order_out(db, o)


@router.get("/orders")
def list_orders(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    rows = db.scalars(select(PurchaseOrder).where(PurchaseOrder.workspace_id == ctx.ws.id)
                      .order_by(PurchaseOrder.id.desc())).all()
    return [order_out(db, o, full=False) for o in rows]


def _order(db, ctx, oid) -> PurchaseOrder:
    o = db.scalar(select(PurchaseOrder).where(PurchaseOrder.id == oid, PurchaseOrder.workspace_id == ctx.ws.id))
    if not o:
        raise HTTPException(404, "Order not found")
    return o


@router.get("/orders/{oid}")
def get_order(oid: int, ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    return order_out(db, _order(db, ctx, oid))


@router.post("/orders/{oid}/submit")
def submit_draft(oid: int, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    o = _order(db, ctx, oid)
    if o.status != "draft":
        raise HTTPException(409, f"Order is {o.status}")
    cc = _cc(db, ctx, o.cost_center_id)
    _submit(db, ctx, o, _quote(o.vendor_key, o.plan_id, cc)["pre_approved"])
    db.commit()
    return order_out(db, o)


@router.post("/orders/{oid}/approve")
def approve(oid: int, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    o = _order(db, ctx, oid)
    if o.status != "pending_approval":
        raise HTTPException(409, f"Order is {o.status}")
    if o.requested_by == ctx.user.id and ctx.role != "owner":
        raise HTTPException(403, "You cannot approve your own order")
    _approve(db, o, ctx.user.id)
    audit(db, ctx, "po.approved", o.number, total=o.total)
    db.commit()
    return order_out(db, o)


@router.post("/orders/{oid}/reject")
def reject(oid: int, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    o = _order(db, ctx, oid)
    if o.status not in ("pending_approval", "draft"):
        raise HTTPException(409, f"Order is {o.status}")
    o.status = "rejected"
    audit(db, ctx, "po.rejected", o.number)
    db.commit()
    return order_out(db, o, full=False)


class StepEvent(BaseModel):
    step_key: str


@router.post("/orders/{oid}/provisioning-events")
def provisioning_event(oid: int, body: StepEvent, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    """Real fulfilment hook (use when PROVISIONING_SIMULATION=false): mark a step complete from your vendor webhook/worker."""
    o = _order(db, ctx, oid)
    s = db.scalar(select(OrderStep).where(OrderStep.order_id == o.id, OrderStep.key == body.step_key))
    if not s:
        raise HTTPException(404, "Unknown step")
    s.status, s.completed_at = "completed", utcnow()
    db.commit()
    return order_out(db, o)


@router.get("/orders/{oid}/invoice", response_class=PlainTextResponse)
def invoice(oid: int, ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    o = _order(db, ctx, oid)
    if o.status in ("draft", "rejected"):
        raise HTTPException(409, "No invoice for this order")
    lines = "\n".join(f"  {i['label']:<52}{i['amount']:>12,.2f}" for i in o.line_items)
    body = (f"INVOICE / PURCHASE ORDER {o.number}\nVendor: {VENDORS[o.vendor_key]['name']}\nAllocation: {o.allocation}\n"
            f"Terms: {o.payment_terms.upper()} • {o.billing_schedule} billing\n\n{lines}\n  {'-' * 64}\n"
            f"  {'TOTAL (' + o.currency + ')':<52}{o.total:>12,.2f}\n\nApproval hash: {o.approval_hash or 'pending'}\n")
    return PlainTextResponse(body, headers={"Content-Disposition": f'attachment; filename="{o.number}.txt"'})
