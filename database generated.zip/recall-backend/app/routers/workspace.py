from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import ROLES, Ctx, admin_only, audit, get_ctx, owner_only, require
from ..models import ApiKey, AuditLog, Invitation, Membership, Memory, User, Workspace
from ..security import new_api_key

router = APIRouter(prefix="/workspace", tags=["workspace & team"])


def _member_out(m: Membership, u: User, me: int) -> dict:
    return {"membership_id": m.id, "user_id": u.id, "full_name": u.full_name, "email": u.email, "title": u.title,
            "avatar_url": u.avatar_url, "role": m.role, "partitions": m.partitions or [], "is_you": u.id == me,
            "last_active_at": m.last_active_at.isoformat()}


@router.get("")
def workspace(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    members = db.query(Membership).filter_by(workspace_id=ctx.ws.id).count()
    pending = db.query(Invitation).filter_by(workspace_id=ctx.ws.id, status="pending").count()
    parts = {p for (p,) in db.execute(select(Memory.partition).where(Memory.workspace_id == ctx.ws.id).distinct())}
    keys = db.query(ApiKey).filter_by(workspace_id=ctx.ws.id, revoked=False).count()
    return {"id": ctx.ws.id, "name": ctx.ws.name, "code": ctx.ws.code, "your_role": ctx.role,
            "members": members, "pending_invites": pending, "seats_remaining": max(0, ctx.ws.seat_limit - members - pending),
            "seat_limit": ctx.ws.seat_limit, "memory_partitions": len(parts), "active_api_keys": keys,
            "settings": ctx.ws.settings}


class SettingsIn(BaseModel):
    isolate_personal_work: bool | None = None
    redact_multi_user: bool | None = None
    audit_replay: bool | None = None


@router.patch("/settings")
def update_settings(body: SettingsIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    ws = db.get(Workspace, ctx.ws.id)
    ws.settings = {**ws.settings, **body.model_dump(exclude_none=True)}
    audit(db, ctx, "workspace.settings", ws.name, **body.model_dump(exclude_none=True))
    db.commit()
    return ws.settings


@router.get("/members")
def members(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    rows = db.execute(select(Membership, User).join(User, User.id == Membership.user_id)
                      .where(Membership.workspace_id == ctx.ws.id).order_by(Membership.id)).all()
    return [_member_out(m, u, ctx.user.id) for m, u in rows]


class InviteIn(BaseModel):
    email: EmailStr
    role: str = "member"
    partitions: list[str] = []


@router.post("/invitations", status_code=201)
def invite(body: InviteIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    if body.role not in ROLES or body.role == "owner":
        raise HTTPException(422, f"role must be one of {[r for r in ROLES if r != 'owner']}")
    used = db.query(Membership).filter_by(workspace_id=ctx.ws.id).count() + \
        db.query(Invitation).filter_by(workspace_id=ctx.ws.id, status="pending").count()
    if used >= ctx.ws.seat_limit:
        raise HTTPException(402, "No seats remaining")
    email = body.email.lower()
    user = db.scalar(select(User).where(User.email == email))
    if user and db.scalar(select(Membership).where(Membership.workspace_id == ctx.ws.id, Membership.user_id == user.id)):
        raise HTTPException(409, "Already a member")
    if user:
        db.add(Membership(workspace_id=ctx.ws.id, user_id=user.id, role=body.role, partitions=body.partitions))
        result = "added"
    else:
        db.add(Invitation(workspace_id=ctx.ws.id, email=email, role=body.role, partitions=body.partitions, invited_by=ctx.user.id))
        result = "invited"  # TODO: send invitation email; invite is auto-accepted on signup
    audit(db, ctx, "member.invite", email, role=body.role)
    db.commit()
    return {"result": result, "email": email}


class MemberPatch(BaseModel):
    role: str | None = None
    partitions: list[str] | None = None


def _member(db, ctx, user_id) -> Membership:
    m = db.scalar(select(Membership).where(Membership.workspace_id == ctx.ws.id, Membership.user_id == user_id))
    if not m:
        raise HTTPException(404, "Member not found")
    return m


@router.patch("/members/{user_id}")
def update_member(user_id: int, body: MemberPatch, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    m = _member(db, ctx, user_id)
    if m.role == "owner":
        raise HTTPException(403, "Owner role can only change via ownership transfer")
    if body.role:
        if body.role not in ROLES or body.role == "owner":
            raise HTTPException(422, "Invalid role")
        if body.role == "admin" and ctx.role != "owner":
            raise HTTPException(403, "Only the owner can grant admin")
        m.role = body.role
    if body.partitions is not None:
        m.partitions = body.partitions
    audit(db, ctx, "member.update", str(user_id), **body.model_dump(exclude_none=True))
    db.commit()
    return {"ok": True}


@router.delete("/members/{user_id}", status_code=204)
def remove_member(user_id: int, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    m = _member(db, ctx, user_id)
    if m.role == "owner":
        raise HTTPException(403, "Cannot remove the owner")
    if m.role == "admin" and ctx.role != "owner":
        raise HTTPException(403, "Only the owner can remove an admin")
    db.delete(m)
    audit(db, ctx, "member.remove", str(user_id))
    db.commit()


class TransferIn(BaseModel):
    user_id: int


@router.post("/transfer-ownership")
def transfer(body: TransferIn, ctx: Ctx = Depends(owner_only), db: Session = Depends(get_db)):
    target = _member(db, ctx, body.user_id)
    if target.user_id == ctx.user.id:
        raise HTTPException(400, "You already own this workspace")
    target.role, ctx.membership.role = "owner", "admin"
    db.get(Workspace, ctx.ws.id).owner_id = target.user_id
    audit(db, ctx, "workspace.transfer", str(body.user_id))
    db.commit()
    return {"new_owner_id": target.user_id}


@router.post("/leave", status_code=204)
def leave(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    if ctx.role == "owner":
        raise HTTPException(409, "Transfer ownership before leaving")
    db.delete(ctx.membership)
    audit(db, ctx, "member.leave", str(ctx.user.id))
    db.commit()


@router.get("/audit-log")
def audit_log(limit: int = 100, ctx: Ctx = Depends(require("owner", "admin", "auditor")), db: Session = Depends(get_db)):
    rows = db.scalars(select(AuditLog).where(AuditLog.workspace_id == ctx.ws.id)
                      .order_by(AuditLog.created_at.desc()).limit(min(limit, 500))).all()
    return [{"id": r.id, "actor_id": r.actor_id, "action": r.action, "target": r.target, "meta": r.meta,
             "at": r.created_at.isoformat()} for r in rows]


# ---------- API keys / service accounts ----------
class KeyIn(BaseModel):
    name: str


@router.get("/api-keys")
def list_keys(ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    rows = db.scalars(select(ApiKey).where(ApiKey.workspace_id == ctx.ws.id, ApiKey.revoked == False)).all()  # noqa: E712
    return [{"id": k.id, "name": k.name, "prefix": k.prefix, "created_at": k.created_at.isoformat(),
             "last_used_at": k.last_used_at.isoformat() if k.last_used_at else None} for k in rows]


@router.post("/api-keys", status_code=201)
def create_key(body: KeyIn, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    raw, prefix, h = new_api_key()
    db.add(ApiKey(workspace_id=ctx.ws.id, created_by=ctx.user.id, name=body.name, prefix=prefix, key_hash=h))
    audit(db, ctx, "apikey.create", body.name)
    db.commit()
    return {"name": body.name, "api_key": raw, "note": "Shown once — store it now. Send as X-API-Key."}


@router.delete("/api-keys/{key_id}", status_code=204)
def revoke_key(key_id: int, ctx: Ctx = Depends(admin_only), db: Session = Depends(get_db)):
    k = db.scalar(select(ApiKey).where(ApiKey.id == key_id, ApiKey.workspace_id == ctx.ws.id))
    if not k:
        raise HTTPException(404, "Key not found")
    k.revoked = True
    audit(db, ctx, "apikey.revoke", k.name)
    db.commit()
