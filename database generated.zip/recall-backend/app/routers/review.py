from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, can_write, get_ctx, visible_memories
from ..models import Memory, ReviewLog, ReviewSession
from ..serializers import elapsed_days, memory_out, memory_retention
from ..services import srs

router = APIRouter(prefix="/review", tags=["review"])


class SessionIn(BaseModel):
    deck_id: int | None = None
    limit: int = 20


class AnswerIn(BaseModel):
    memory_id: int
    grade: str  # again|hard|good|easy
    response_ms: int | None = None


def _state(m: Memory) -> srs.CardState:
    return srs.CardState(m.ease, m.interval_days, m.repetitions, m.lapses)


def _due_query(ctx, deck_id=None):
    q = visible_memories(ctx).where(Memory.due_at <= utcnow())
    return q.where(Memory.deck_id == deck_id) if deck_id else q


def _card(m: Memory, now) -> dict:
    return {**memory_out(m, now), "intervals": srs.preview(_state(m)),
            "retention_forecast_30d": srs.forecast(m.interval_days, elapsed_days(m, now))}


def _sorted_due(rows, now):
    # weakest memories first; never-reviewed cards get a neutral 0.5
    return sorted(rows, key=lambda m: memory_retention(m, now) if memory_retention(m, now) is not None else 0.5)


@router.get("/queue")
def queue(deck_id: int | None = None, limit: int = Query(20, ge=1, le=100),
          ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    now = utcnow()
    rows = _sorted_due(db.scalars(_due_query(ctx, deck_id)).all(), now)
    return {"total_due": len(rows), "cards": [_card(m, now) for m in rows[:limit]]}


@router.post("/sessions", status_code=201)
def start_session(body: SessionIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    now = utcnow()
    rows = _sorted_due(db.scalars(_due_query(ctx, body.deck_id)).all(), now)[: max(1, min(body.limit, 100))]
    if not rows:
        raise HTTPException(409, "Nothing due — you're all caught up")
    s = ReviewSession(workspace_id=ctx.ws.id, user_id=ctx.user.id, deck_id=body.deck_id, card_ids=[m.id for m in rows])
    db.add(s)
    db.commit()
    return {"session_id": s.id, "total": len(rows), "started_at": s.started_at.isoformat(),
            "cards": [_card(m, now) for m in rows]}


def _session(db, ctx, sid) -> ReviewSession:
    s = db.scalar(select(ReviewSession).where(ReviewSession.id == sid, ReviewSession.user_id == ctx.user.id))
    if not s:
        raise HTTPException(404, "Session not found")
    return s


@router.post("/sessions/{sid}/answer")
def answer(sid: int, body: AnswerIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    s = _session(db, ctx, sid)
    if s.ended_at:
        raise HTTPException(409, "Session already finished")
    if body.memory_id not in s.card_ids:
        raise HTTPException(400, "Card is not part of this session")
    if body.grade not in srs.GRADES:
        raise HTTPException(422, f"grade must be one of {list(srs.GRADES)}")
    if db.scalar(select(ReviewLog.id).where(ReviewLog.session_id == sid, ReviewLog.memory_id == body.memory_id)):
        raise HTTPException(409, "Card already answered in this session")
    m = db.scalar(visible_memories(ctx).where(Memory.id == body.memory_id))
    if not m:
        raise HTTPException(404, "Memory not found")
    now = utcnow()
    before = m.interval_days
    new = srs.next_state(_state(m), body.grade)
    m.ease, m.interval_days, m.repetitions, m.lapses = new.ease, new.interval_days, new.repetitions, new.lapses
    m.last_reviewed_at, m.due_at = now, now + timedelta(days=new.interval_days)
    m.recall_count += 1
    db.add(ReviewLog(workspace_id=ctx.ws.id, user_id=ctx.user.id, memory_id=m.id, session_id=sid, grade=body.grade,
                     correct=body.grade != "again", response_ms=body.response_ms, interval_before=before,
                     interval_after=new.interval_days, reviewed_at=now))
    db.commit()
    done = db.query(ReviewLog).filter(ReviewLog.session_id == sid).count()
    return {"memory_id": m.id, "next_review_in": srs.interval_label(new.interval_days), "due_at": m.due_at.isoformat(),
            "progress": {"answered": done, "total": len(s.card_ids)}}


@router.post("/sessions/{sid}/finish")
def finish(sid: int, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    s = _session(db, ctx, sid)
    s.ended_at = s.ended_at or utcnow()
    db.commit()
    logs = db.scalars(select(ReviewLog).where(ReviewLog.session_id == sid)).all()
    lat = [l.response_ms for l in logs if l.response_ms]
    return {"session_id": s.id, "reviewed": len(logs), "of": len(s.card_ids),
            "accuracy": round(sum(l.correct for l in logs) / len(logs), 3) if logs else None,
            "avg_latency_ms": round(sum(lat) / len(lat)) if lat else None,
            "duration_s": int((s.ended_at - s.started_at).total_seconds()),
            "grades": {g: sum(1 for l in logs if l.grade == g) for g in srs.GRADES}}


@router.get("/sessions/{sid}")
def get_session(sid: int, ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    s = _session(db, ctx, sid)
    answered = {l.memory_id for l in db.scalars(select(ReviewLog).where(ReviewLog.session_id == sid))}
    remaining = [i for i in s.card_ids if i not in answered]
    return {"session_id": s.id, "total": len(s.card_ids), "answered": len(answered), "remaining_ids": remaining,
            "elapsed_s": int(((s.ended_at or utcnow()) - s.started_at).total_seconds()), "finished": bool(s.ended_at)}
