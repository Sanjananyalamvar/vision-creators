from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, audit, can_write, get_ctx, visible_memories
from ..models import Deck, Memory
from ..serializers import memory_out, memory_retention
from ..services import text

router = APIRouter(prefix="/memories", tags=["memories"])


class MemoryIn(BaseModel):
    content: str = Field(min_length=1, max_length=20000)  # "Quick capture": text, insight or URL
    title: str | None = None
    question: str | None = None
    answer: str | None = None
    hint: str | None = None
    deck_id: int | None = None
    tags: list[str] = []
    source: str = "manual"  # manual|voice|photo|doc|claude|chatgpt|cursor|...
    partition: str = "personal"


class MemoryPatch(BaseModel):
    title: str | None = None
    content: str | None = None
    question: str | None = None
    answer: str | None = None
    hint: str | None = None
    deck_id: int | None = None
    tags: list[str] | None = None
    partition: str | None = None
    pinned: bool | None = None


def _check_deck(db, ctx, deck_id):
    if deck_id and not db.scalar(select(Deck).where(Deck.id == deck_id, Deck.workspace_id == ctx.ws.id)):
        raise HTTPException(404, "Deck not found")


def _get(db, ctx, mid) -> Memory:
    m = db.scalar(visible_memories(ctx).where(Memory.id == mid))
    if not m:
        raise HTTPException(404, "Memory not found")
    return m


@router.post("", status_code=201)
def capture(body: MemoryIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    _check_deck(db, ctx, body.deck_id)
    content = body.content.strip()
    url = content if text.is_url(content) else None
    tags = sorted({t.lower().lstrip("#") for t in body.tags} | set(text.extract_tags(content)))
    title = body.title or (url or text.first_sentence(content, 80))
    m = Memory(
        workspace_id=ctx.ws.id, owner_id=ctx.user.id, deck_id=body.deck_id, title=title[:255], content=content,
        question=body.question or title, answer=body.answer or content, hint=body.hint, url=url,
        source=body.source, tags=tags, partition=body.partition, due_at=utcnow(),
    )
    db.add(m)
    audit(db, ctx, "memory.create", title[:80], source=body.source)
    db.commit()
    return memory_out(m)


@router.get("")
def list_memories(
    q: str | None = None, tag: str | None = None, deck_id: int | None = None,
    status: str = Query("all", pattern="^(all|due|reviewed|new)$"),
    sort: str = Query("recent", pattern="^(recent|decay|due)$"),
    limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
    ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db),
):
    query = visible_memories(ctx)
    now = utcnow()
    if deck_id:
        query = query.where(Memory.deck_id == deck_id)
    if status == "due":
        query = query.where(Memory.due_at <= now)
    elif status == "reviewed":
        query = query.where(Memory.last_reviewed_at.is_not(None))
    elif status == "new":
        query = query.where(Memory.last_reviewed_at.is_(None))
    rows = db.scalars(query.order_by(Memory.created_at.desc()).limit(5000)).all()
    if tag:
        rows = [m for m in rows if tag.lower().lstrip("#") in (m.tags or [])]
    scored = [(m, None) for m in rows]
    if q:  # semantic-ish search; replace with vector store when connected
        scored = sorted(((m, text.similarity(q, f"{m.title} {m.content} {' '.join(m.tags or [])}")) for m in rows),
                        key=lambda t: t[1], reverse=True)
        scored = [t for t in scored if t[1] > 0 or q.lower() in (t[0].content or "").lower()]
    elif sort == "decay":
        scored.sort(key=lambda t: (memory_retention(t[0], now) if memory_retention(t[0], now) is not None else 0.5))
    elif sort == "due":
        scored.sort(key=lambda t: t[0].due_at)
    page = scored[offset: offset + limit]
    return {"total": len(scored), "items": [{**memory_out(m, now, include_answer=False), "similarity": s} for m, s in page]}


@router.get("/search")
def semantic_search(q: str, limit: int = Query(10, ge=1, le=50), ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    """Recall endpoint for agents (Claude/ChatGPT/Cursor) — use with X-API-Key."""
    rows = db.scalars(visible_memories(ctx).limit(5000)).all()
    hits = sorted(((m, text.similarity(q, f"{m.title} {m.content}")) for m in rows), key=lambda t: t[1], reverse=True)
    out = []
    for m, s in hits[:limit]:
        if s <= 0:
            break
        m.recall_count += 1
        out.append({**memory_out(m), "similarity": s})
    db.commit()
    return {"query": q, "results": out}


@router.get("/{mid}")
def get_memory(mid: int, ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    return memory_out(_get(db, ctx, mid))


@router.patch("/{mid}")
def update_memory(mid: int, body: MemoryPatch, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    m = _get(db, ctx, mid)
    if ctx.role == "member" and m.owner_id != ctx.user.id:
        raise HTTPException(403, "Members can only edit their own memories")
    data = body.model_dump(exclude_unset=True)
    if "deck_id" in data:
        _check_deck(db, ctx, data["deck_id"])
    if "tags" in data:
        data["tags"] = sorted({t.lower().lstrip("#") for t in data["tags"]})
    for k, v in data.items():
        setattr(m, k, v)
    audit(db, ctx, "memory.update", m.title[:80])
    db.commit()
    return memory_out(m)


@router.delete("/{mid}", status_code=204)
def delete_memory(mid: int, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    m = _get(db, ctx, mid)
    if ctx.role == "member" and m.owner_id != ctx.user.id:
        raise HTTPException(403, "Members can only delete their own memories")
    m.archived = True  # soft delete keeps review history intact
    audit(db, ctx, "memory.delete", m.title[:80])
    db.commit()
