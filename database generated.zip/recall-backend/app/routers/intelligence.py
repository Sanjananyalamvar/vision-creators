import re
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, audit, can_write, get_ctx, visible_memories
from ..models import ApiKey, Contradiction, Memory, ReviewLog
from ..serializers import memory_out, memory_retention
from ..services import srs, text

router = APIRouter(prefix="/intelligence", tags=["knowledge intelligence"])


@router.get("/overview")
def overview(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    now = utcnow()
    mems = db.scalars(visible_memories(ctx)).all()
    week_ago = now.replace(hour=0, minute=0) - timedelta(days=7)
    open_contra = db.query(Contradiction).filter_by(workspace_id=ctx.ws.id, status="open").count()
    dupes = len(_duplicate_groups(mems))
    reviewed_today = db.query(ReviewLog).filter(ReviewLog.user_id == ctx.user.id,
                                                ReviewLog.reviewed_at >= now.replace(hour=0, minute=0, second=0)).count()
    keys = db.scalars(select(ApiKey).where(ApiKey.workspace_id == ctx.ws.id, ApiKey.revoked == False)).all()  # noqa: E712
    return {
        "retention": srs.mean(memory_retention(m, now) for m in mems),
        "active_facts": len(mems), "new_this_week": sum(1 for m in mems if m.created_at >= week_ago),
        "health": {"alerts": open_contra + dupes, "status": "optimal" if open_contra + dupes <= 2 else "needs_review"},
        "tuneup": {"reviewed": min(reviewed_today, 5), "of": 5, "spaced_interval_days": 4},
        "broadcast": [{"name": k.name, "last_used_at": k.last_used_at.isoformat() if k.last_used_at else None} for k in keys],
        "counts": {"contradictions": open_contra, "duplicates": dupes},
    }


@router.get("/clusters")
def clusters(limit: int = Query(6, ge=1, le=20), ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    now = utcnow()
    groups: dict[str, list[Memory]] = {}
    for m in db.scalars(visible_memories(ctx)):
        for t in (m.tags or ["untagged"])[:1]:  # primary tag = cluster
            groups.setdefault(t, []).append(m)
    out = [{"name": k, "facts": len(v), "recall": srs.mean(memory_retention(m, now) for m in v)} for k, v in groups.items()]
    return sorted(out, key=lambda c: c["facts"], reverse=True)[:limit]


@router.get("/tuneup")
def tuneup(size: int = Query(5, ge=1, le=20), ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    """Daily Memory Tune-up: weakest reviewed memories, shown as active-recall prompts."""
    now = utcnow()
    rows = [m for m in db.scalars(visible_memories(ctx)) if m.last_reviewed_at]
    rows.sort(key=lambda m: memory_retention(m, now))
    return [memory_out(m, now, include_answer=False) for m in rows[:size]]


# ---------- contradictions ----------
def _numbers(s: str) -> set[str]:
    return set(re.findall(r"\d+(?::\d+)?", s or ""))


def _detect(mems: list[Memory]) -> list[tuple[Memory, Memory]]:
    pairs = []
    for i, a in enumerate(mems):
        for b in mems[i + 1:]:
            if set(a.tags or []) & set(b.tags or []) or text.jaccard(a.title, b.title) > 0.4:
                sim = text.jaccard(a.content, b.content)
                differing = _numbers(a.content) != _numbers(b.content) and (_numbers(a.content) or _numbers(b.content))
                if 0.25 <= sim < 0.9 and differing:
                    pairs.append((a, b))
    return pairs


@router.post("/contradictions/detect")
def detect(ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    """Heuristic pass (same topic, overlapping wording, different numbers). Swap for an LLM judge if desired."""
    mems = db.scalars(visible_memories(ctx).limit(1000)).all()
    existing = {(c.memory_a_id, c.memory_b_id) for c in db.scalars(select(Contradiction).where(Contradiction.workspace_id == ctx.ws.id))}
    created = 0
    for a, b in _detect(mems):
        if (a.id, b.id) in existing or (b.id, a.id) in existing:
            continue
        db.add(Contradiction(workspace_id=ctx.ws.id, memory_a_id=a.id, memory_b_id=b.id,
                             statement_a=a.content[:500], statement_b=b.content[:500]))
        created += 1
    db.commit()
    return {"new_contradictions": created}


@router.get("/contradictions")
def list_contradictions(status: str = "open", ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    rows = db.scalars(select(Contradiction).where(Contradiction.workspace_id == ctx.ws.id, Contradiction.status == status)
                      .order_by(Contradiction.created_at.desc())).all()
    return [{"id": c.id, "memory_a_id": c.memory_a_id, "memory_b_id": c.memory_b_id, "statement_a": c.statement_a,
             "statement_b": c.statement_b, "status": c.status, "detected_at": c.created_at.isoformat()} for c in rows]


class ResolveIn(BaseModel):
    keep: str  # a | b | merge
    merged_text: str | None = None


@router.post("/contradictions/{cid}/resolve")
def resolve(cid: int, body: ResolveIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    c = db.scalar(select(Contradiction).where(Contradiction.id == cid, Contradiction.workspace_id == ctx.ws.id))
    if not c or c.status != "open":
        raise HTTPException(404, "Open contradiction not found")
    a, b = db.get(Memory, c.memory_a_id), db.get(Memory, c.memory_b_id)
    if body.keep == "a":
        b.archived = True
    elif body.keep == "b":
        a.archived = True
    elif body.keep == "merge":
        if not body.merged_text:
            raise HTTPException(422, "merged_text required for merge")
        a.content = a.answer = body.merged_text
        b.archived = True
    else:
        raise HTTPException(422, "keep must be a, b or merge")
    c.status, c.resolution = "resolved", body.keep
    audit(db, ctx, "contradiction.resolve", str(cid), keep=body.keep)
    db.commit()
    return {"status": "resolved"}


@router.post("/contradictions/{cid}/dismiss")
def dismiss(cid: int, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    c = db.scalar(select(Contradiction).where(Contradiction.id == cid, Contradiction.workspace_id == ctx.ws.id))
    if not c:
        raise HTTPException(404, "Not found")
    c.status = "dismissed"
    db.commit()
    return {"status": "dismissed"}


# ---------- deduplication ----------
def _duplicate_groups(mems: list[Memory], threshold: float = 0.8) -> list[list[Memory]]:
    seen, groups = set(), []
    for i, a in enumerate(mems):
        if a.id in seen:
            continue
        g = [a] + [b for b in mems[i + 1:] if b.id not in seen and text.jaccard(a.content, b.content) >= threshold]
        if len(g) > 1:
            seen.update(m.id for m in g)
            groups.append(g)
    return groups


@router.get("/duplicates")
def duplicates(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    mems = db.scalars(visible_memories(ctx).limit(2000)).all()
    return [{"keep_suggestion": g[0].id, "memories": [memory_out(m, include_answer=False) for m in g]}
            for g in _duplicate_groups(mems)]


class MergeIn(BaseModel):
    keep_id: int
    merge_ids: list[int]


@router.post("/duplicates/merge")
def merge(body: MergeIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    keep = db.scalar(visible_memories(ctx).where(Memory.id == body.keep_id))
    if not keep:
        raise HTTPException(404, "Memory to keep not found")
    n = 0
    for m in db.scalars(visible_memories(ctx).where(Memory.id.in_(body.merge_ids))):
        if m.id == keep.id:
            continue
        keep.tags = sorted(set(keep.tags or []) | set(m.tags or []))
        keep.recall_count += m.recall_count
        m.archived = True
        n += 1
    audit(db, ctx, "memory.dedupe", str(keep.id), merged=n)
    db.commit()
    return {"kept": keep.id, "merged": n}
