from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, can_write, get_ctx, visible_memories
from ..models import Deck, Memory
from ..serializers import memory_retention
from ..services import srs

router = APIRouter(prefix="/decks", tags=["decks"])


class DeckIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    icon: str = "layers"


def deck_out(d: Deck, cards: list[Memory], now) -> dict:
    due = [c for c in cards if c.due_at <= now]
    reviewed = [c.last_reviewed_at for c in cards if c.last_reviewed_at]
    return {
        "id": d.id, "name": d.name, "icon": d.icon, "card_count": len(cards), "due_count": len(due),
        "retention": srs.mean(memory_retention(c, now) for c in cards),
        "last_recalled_at": max(reviewed).isoformat() if reviewed else None,
    }


@router.get("")
def list_decks(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    now = utcnow()
    decks = db.scalars(select(Deck).where(Deck.workspace_id == ctx.ws.id).order_by(Deck.id)).all()
    cards = db.scalars(visible_memories(ctx).where(Memory.deck_id.is_not(None))).all()
    by_deck: dict[int, list] = {}
    for c in cards:
        by_deck.setdefault(c.deck_id, []).append(c)
    return [deck_out(d, by_deck.get(d.id, []), now) for d in decks]


@router.post("", status_code=201)
def create_deck(body: DeckIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    d = Deck(workspace_id=ctx.ws.id, owner_id=ctx.user.id, name=body.name, icon=body.icon)
    db.add(d)
    db.commit()
    return deck_out(d, [], utcnow())


@router.patch("/{deck_id}")
def rename_deck(deck_id: int, body: DeckIn, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    d = db.scalar(select(Deck).where(Deck.id == deck_id, Deck.workspace_id == ctx.ws.id))
    if not d:
        raise HTTPException(404, "Deck not found")
    d.name, d.icon = body.name, body.icon
    db.commit()
    return {"id": d.id, "name": d.name, "icon": d.icon}


@router.delete("/{deck_id}", status_code=204)
def delete_deck(deck_id: int, ctx: Ctx = Depends(can_write), db: Session = Depends(get_db)):
    d = db.scalar(select(Deck).where(Deck.id == deck_id, Deck.workspace_id == ctx.ws.id))
    if not d:
        raise HTTPException(404, "Deck not found")
    for m in db.scalars(select(Memory).where(Memory.deck_id == d.id)):
        m.deck_id = None  # cards survive, just unfiled
    db.delete(d)
    db.commit()
