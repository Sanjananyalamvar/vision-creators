from datetime import timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, get_ctx, visible_memories
from ..models import Memory, ReviewLog
from ..serializers import memory_out, memory_retention
from ..services import srs
from .decks import list_decks

router = APIRouter(tags=["dashboard"])

SECONDS_PER_CARD = 20


def streak_days(db: Session, ctx: Ctx) -> int:
    days = {d.date() for d in db.scalars(select(ReviewLog.reviewed_at).where(ReviewLog.user_id == ctx.user.id))}
    day = utcnow().date()
    if day not in days:  # streak stays alive until the day ends
        day -= timedelta(days=1)
    n = 0
    while day in days:
        n += 1
        day -= timedelta(days=1)
    return n


def _recall_rate(logs) -> float | None:
    return round(sum(l.correct for l in logs) / len(logs), 4) if logs else None


@router.get("/dashboard")
def dashboard(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    now = utcnow()
    mems = db.scalars(visible_memories(ctx)).all()
    due = [m for m in mems if m.due_at <= now]
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    logs_week = db.scalars(select(ReviewLog).where(ReviewLog.user_id == ctx.user.id,
                                                  ReviewLog.reviewed_at >= now - timedelta(days=14))).all()
    reviewed_today = sum(1 for l in logs_week if l.reviewed_at >= today_start)
    this_w = [l for l in logs_week if l.reviewed_at >= now - timedelta(days=7)]
    prev_w = [l for l in logs_week if l.reviewed_at < now - timedelta(days=7)]
    a, b = _recall_rate(this_w), _recall_rate(prev_w)
    hours = [l.reviewed_at.hour for l in this_w if l.correct]
    peak = max(set(hours), key=hours.count) if hours else None
    stream = sorted(mems, key=lambda m: memory_retention(m, now) if memory_retention(m, now) is not None else 0.5)[:10]
    return {
        "greeting_name": ctx.user.full_name.split()[0],
        "streak_days": streak_days(db, ctx),
        "queue": {"due": len(due), "reviewed_today": reviewed_today,
                  "percent_done_today": round(100 * reviewed_today / (reviewed_today + len(due))) if (reviewed_today + len(due)) else 100,
                  "high_urgency": sum(1 for m in due if (memory_retention(m, now) or 1) < 0.5),
                  "estimated_minutes": max(1, round(len(due) * SECONDS_PER_CARD / 60)) if due else 0},
        "retention": {"average": srs.mean(memory_retention(m, now) for m in mems),
                      "target": 0.9,
                      "retrieval_rate_change_pct": round((a - b) * 100) if a is not None and b is not None else None,
                      "peak_hour_utc": peak},
        "items_total": len(mems),
        "latest_memory": memory_out(max(mems, key=lambda m: m.created_at), now, False) if mems else None,
        "stream": [memory_out(m, now, False) for m in stream],
        "decks": list_decks(ctx, db),
        "notifications": sum(1 for m in due if (memory_retention(m, now) or 1) < 0.5),
    }


@router.get("/stats")
def stats(ctx: Ctx = Depends(get_ctx), db: Session = Depends(get_db)):
    now = utcnow()
    logs = db.scalars(select(ReviewLog).where(ReviewLog.user_id == ctx.user.id)
                      .order_by(ReviewLog.reviewed_at.desc())).all()
    lat = [l.response_ms for l in logs if l.response_ms]
    mems = db.scalars(visible_memories(ctx)).all()
    mastered = sum(1 for m in mems if m.interval_days >= 21)
    by_day: dict[str, list] = {}
    for l in logs:
        by_day.setdefault(l.reviewed_at.date().isoformat(), []).append(l)
    return {
        "total_reviewed": len(logs), "streak_days": streak_days(db, ctx),
        "avg_latency_ms": round(sum(lat) / len(lat)) if lat else None,
        "mastery": {"mastered": mastered, "total": len(mems), "percent": round(100 * mastered / len(mems)) if mems else 0, "target": 90},
        "forecast_30d": srs.mean(srs.forecast(m.interval_days, (now - m.last_reviewed_at).total_seconds() / 86400)
                                 for m in mems if m.last_reviewed_at),
        "daily": [{"date": d, "reviews": len(v), "accuracy": _recall_rate(v),
                   "avg_latency_ms": round(sum(x.response_ms for x in v if x.response_ms) / max(1, sum(1 for x in v if x.response_ms)))}
                  for d, v in sorted(by_day.items(), reverse=True)[:7]],
    }
