import secrets
import string
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from ..database import get_db, utcnow
from ..deps import Ctx, get_ctx
from ..models import CostCenter, Deck, Invitation, Membership, User, Workspace
from ..security import create_token, hash_password, sha256, verify_password
from ..serializers import user_out

router = APIRouter(prefix="/auth", tags=["auth"])


class SignupIn(BaseModel):
    full_name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    handle: str | None = Field(default=None, max_length=64)
    accepted_terms: bool = True


class LoginIn(BaseModel):
    identifier: str  # email or handle ("synapse://user" style handles are accepted)
    password: str
    remember_me: bool = False


class ForgotIn(BaseModel):
    email: EmailStr


class ResetIn(BaseModel):
    token: str
    new_password: str = Field(min_length=8, max_length=128)


def _token_response(user: User, remember: bool = False) -> dict:
    token, ttl = create_token(user.id, remember)
    return {"access_token": token, "token_type": "bearer", "expires_in": ttl, "user": user_out(user)}


@router.post("/signup", status_code=201)
def signup(body: SignupIn, db: Session = Depends(get_db)):
    if not body.accepted_terms:
        raise HTTPException(422, "Terms must be accepted")
    email = body.email.lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Email already registered")
    if body.handle and db.scalar(select(User).where(User.handle == body.handle)):
        raise HTTPException(status.HTTP_409_CONFLICT, "Handle already taken")
    user = User(email=email, handle=body.handle, full_name=body.full_name.strip(),
                password_hash=hash_password(body.password))
    db.add(user)
    db.flush()

    # accept pending invitations, otherwise create a personal workspace
    invites = db.scalars(select(Invitation).where(Invitation.email == email, Invitation.status == "pending")).all()
    for inv in invites:
        db.add(Membership(workspace_id=inv.workspace_id, user_id=user.id, role=inv.role, partitions=inv.partitions))
        inv.status = "accepted"
    if not invites:
        code = "".join(secrets.choice(string.hexdigits.upper()[:16]) for _ in range(4))
        ws = Workspace(name=f"{user.full_name.split()[0]}'s Workspace", code=f"WS-0x{code}", owner_id=user.id)
        db.add(ws)
        db.flush()
        db.add(Membership(workspace_id=ws.id, user_id=user.id, role="owner", partitions=["personal"]))
        db.add(Deck(workspace_id=ws.id, owner_id=user.id, name="Inbox", icon="inbox"))
        db.add(CostCenter(workspace_id=ws.id, code="CC-GENERAL-001", name="General", quarterly_budget=12500))
    db.commit()
    return _token_response(user)


@router.post("/login")
def login(body: LoginIn, db: Session = Depends(get_db)):
    ident = body.identifier.strip().lower().removeprefix("synapse://")
    user = db.scalar(select(User).where(or_(User.email == ident, User.handle == ident)))
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    return _token_response(user, body.remember_me)


@router.get("/me")
def me(ctx: Ctx = Depends(get_ctx)):
    return {**user_out(ctx.user), "workspace": {"id": ctx.ws.id, "name": ctx.ws.name, "role": ctx.role}}


@router.post("/forgot-password")
def forgot_password(body: ForgotIn, db: Session = Depends(get_db)):
    """Always 200 so accounts can't be enumerated. Plug an email sender in where marked."""
    user = db.scalar(select(User).where(User.email == body.email.lower()))
    if user:
        raw = secrets.token_urlsafe(32)
        user.reset_token_hash, user.reset_expires = sha256(raw), utcnow() + timedelta(hours=1)
        db.commit()
        print(f"[dev] password reset token for {user.email}: {raw}")  # TODO: send email
    return {"detail": "If that account exists, a reset link has been sent."}


@router.post("/reset-password")
def reset_password(body: ResetIn, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.reset_token_hash == sha256(body.token)))
    if not user or not user.reset_expires or user.reset_expires < utcnow():
        raise HTTPException(400, "Invalid or expired token")
    user.password_hash = hash_password(body.new_password)
    user.reset_token_hash = user.reset_expires = None
    db.commit()
    return {"detail": "Password updated"}


@router.post("/oauth/{provider}")
def oauth(provider: str):
    """Google / Apple / GitHub / passkey / Face ID buttons.
    Needs provider client IDs and token verification — left as an integration point."""
    raise HTTPException(501, f"OAuth for '{provider}' is not configured. See README → 'Social login & biometrics'.")
