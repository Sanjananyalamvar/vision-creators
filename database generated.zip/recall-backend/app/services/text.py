"""Lightweight text utilities: tokenizing, similarity search, tag/URL extraction.
Swap `similarity` for a real vector store (Pinecone/Qdrant, see vendors) when connected."""
import math
import re
from collections import Counter

_WORD = re.compile(r"[a-z0-9]+")
_STOP = set("a an the and or of to in on for with is are was be it this that as at by from".split())
_TAG = re.compile(r"(?<!\w)#([A-Za-z][\w-]{1,30})")
_URL = re.compile(r"^https?://\S+$")


def tokens(text: str) -> list[str]:
    return [w for w in _WORD.findall((text or "").lower()) if w not in _STOP]


def similarity(a: str, b: str) -> float:
    ca, cb = Counter(tokens(a)), Counter(tokens(b))
    if not ca or not cb:
        return 0.0
    dot = sum(ca[t] * cb[t] for t in ca)
    return round(dot / (math.sqrt(sum(v * v for v in ca.values())) * math.sqrt(sum(v * v for v in cb.values()))), 4)


def jaccard(a: str, b: str) -> float:
    sa, sb = set(tokens(a)), set(tokens(b))
    return len(sa & sb) / len(sa | sb) if sa and sb else 0.0


def extract_tags(text: str) -> list[str]:
    return sorted({t.lower() for t in _TAG.findall(text or "")})


def is_url(text: str) -> bool:
    return bool(_URL.match((text or "").strip()))


def first_sentence(text: str, limit: int = 120) -> str:
    s = re.split(r"(?<=[.!?])\s", (text or "").strip(), maxsplit=1)[0]
    return s[:limit]
