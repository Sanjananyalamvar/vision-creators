"""Static vendor catalog + purchasable plans. Move to DB / vendor APIs when you outgrow it."""

VENDORS = {
    "pinecone": {"name": "Pinecone", "category": "vector", "tagline": "Serverless Vector DB", "verified": True,
                 "probe_url": "https://api.pinecone.io", "regions": ["us-east-1", "eu-west-1", "us-central1"],
                 "dims": [768, 1536, 3072], "description": "Fast approximate nearest neighbor index for retrieval."},
    "qdrant": {"name": "Qdrant Cloud", "category": "vector", "tagline": "Primary semantic vector space", "verified": True,
               "probe_url": "https://cloud.qdrant.io", "regions": ["us-east-1", "eu-central-1"], "dims": [768, 1536, 3072],
               "description": "HNSW vector search."},
    "weaviate": {"name": "Weaviate Cloud", "category": "vector", "tagline": "Hybrid dense + sparse (BM25)", "verified": True,
                 "probe_url": "https://weaviate.io", "regions": ["us-east-1", "eu-west-1"], "dims": [768, 1536, 3072],
                 "description": "Hybrid search with structured metadata."},
    "openai": {"name": "OpenAI", "category": "llm", "tagline": "GPT-4o • text-embedding-3-large", "verified": True,
               "probe_url": "https://api.openai.com", "regions": [], "dims": [1536, 3072], "description": "LLM + embeddings."},
    "anthropic": {"name": "Anthropic", "category": "llm", "tagline": "Claude • deduplication node", "verified": True,
                  "probe_url": "https://api.anthropic.com", "regions": [], "dims": [], "description": "LLM inference."},
    "mistral": {"name": "Mistral AI", "category": "llm", "tagline": "EU sovereign • Codestral & Large", "verified": True,
                "probe_url": "https://api.mistral.ai", "regions": ["eu-west-1"], "dims": [], "description": "EU-hosted LLMs."},
    "groq": {"name": "Groq Cloud", "category": "llm", "tagline": "Llama 3.3 70B • edge query expansion", "verified": True,
             "probe_url": "https://api.groq.com", "regions": [], "dims": [], "description": "Low-latency inference."},
    "cohere": {"name": "Cohere", "category": "embeddings", "tagline": "Embeddings & rerank", "verified": True,
               "probe_url": "https://api.cohere.com", "regions": [], "dims": [768, 1024], "description": "Embeddings / rerank."},
    "aws-bedrock": {"name": "AWS Bedrock", "category": "cloud", "tagline": "Claude & Titan in your VPC", "verified": True,
                    "probe_url": "https://bedrock.us-east-1.amazonaws.com", "regions": ["us-east-1", "eu-west-1"], "dims": [],
                    "description": "Dedicated enterprise enclave with isolated IAM."},
}

# Purchasable plans (drives /procurement quote). Prices are placeholders — load from your vendor contracts.
PLANS = {
    ("pinecone", "enterprise-50m"): {
        "label": "Q3 Enterprise Tier", "allocation": "50M Vectors / 1536-dim",
        "lines": [("Base Infrastructure (50M Query Nodes)", 1240.00, True),
                  ("Enterprise SLA & 99.99% Uptime Enclave", 350.00, True),
                  ("Zero-Knowledge Security Add-on Bundle", 0.00, True)],
    },
    ("qdrant", "cloud-standard"): {
        "label": "Standard Cluster", "allocation": "10M Vectors / 1536-dim",
        "lines": [("Managed cluster (10M vectors)", 420.00, True), ("Backups & snapshots", 60.00, True)],
    },
}

PROVISIONING_STEPS = [  # (key, label, detail, simulated delay seconds from approval)
    ("payment", "Payment Authorized", "Payment processor authorization", 0),
    ("contract", "Procurement Contract Dispatched", "ERP sync", 3),
    ("cluster", "Cluster Node Allocation", "Provisioning nodes in target region", 15),
    ("index", "Vector Index Active & Key Injected", "Awaiting handshake from vendor gateway", 45),
]
