"""Pure quote maths (no framework imports)."""


def build_quote(lines: list[tuple[str, float, bool]], discount_rate: float, tax_rate: float) -> dict:
    """lines: (label, amount, discountable). Discount applies to discountable lines only; tax to the net."""
    subtotal = round(sum(a for _, a, _ in lines), 2)
    discountable = sum(a for _, a, d in lines if d)
    discount = round(discountable * discount_rate, 2)
    tax = round((subtotal - discount) * tax_rate, 2)
    total = round(subtotal - discount + tax, 2)
    items = [{"label": l, "amount": round(a, 2)} for l, a, _ in lines]
    if discount:
        items.append({"label": f"Volume Discount (-{round(discount_rate * 100)}%)", "amount": -discount})
    items.append({"label": "Estimated Taxes & Regional Tariffs", "amount": tax})
    return {"items": items, "subtotal": subtotal, "discount": discount, "tax": tax, "total": total}


def budget_impact(spent: float, budget: float, total: float) -> dict:
    pct = round(100 * (spent + total) / budget, 1) if budget else None
    return {"budget": budget, "spent": spent, "after_order": round(spent + total, 2), "percent": pct,
            "status": None if pct is None else "healthy" if pct < 80 else "watch" if pct <= 100 else "over_budget"}
