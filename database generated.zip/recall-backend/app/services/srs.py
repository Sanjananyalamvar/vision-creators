"""Pure spaced-repetition logic (SM-2 variant). No DB / framework imports so it is easy to test."""
import math
from dataclasses import dataclass

GRADES = ("again", "hard", "good", "easy")
AGAIN_DAYS = 10 / 1440  # "Again" -> 10 minutes


@dataclass
class CardState:
    ease: float = 2.5
    interval_days: float = 0.0
    repetitions: int = 0
    lapses: int = 0


def next_state(s: CardState, grade: str) -> CardState:
    if grade not in GRADES:
        raise ValueError(f"grade must be one of {GRADES}")
    ease, interval, reps, lapses = s.ease, s.interval_days, s.repetitions, s.lapses
    if grade == "again":
        return CardState(max(1.3, ease - 0.2), AGAIN_DAYS, 0, lapses + 1)
    if grade == "hard":
        interval = max(1.0, interval * 1.2)
        ease = max(1.3, ease - 0.15)
    elif grade == "good":
        interval = 1.0 if reps == 0 else 4.0 if reps == 1 else interval * ease
    else:  # easy
        interval = 4.0 if reps == 0 else 10.0 if reps == 1 else interval * ease * 1.3
        ease += 0.15
    return CardState(round(ease, 3), round(interval, 3), reps + 1, lapses)


def preview(s: CardState) -> dict:
    """Interval each grade would produce — drives the 'Again 10m / Hard 1d / Good 4d / Easy 10d' buttons."""
    return {g: interval_label(next_state(s, g).interval_days) for g in GRADES}


def interval_label(days: float) -> str:
    if days < 1 / 24:
        return f"{max(1, round(days * 1440))}m"
    if days < 1:
        return f"{round(days * 24)}h"
    return f"{round(days)}d"


def retention(interval_days: float, elapsed_days: float | None) -> float | None:
    """Estimated recall probability; equals 0.9 when elapsed == interval. None = never reviewed."""
    if elapsed_days is None:
        return None
    stability = max(interval_days, 1.0)
    return round(0.9 ** (max(elapsed_days, 0) / stability), 4)


def forecast(interval_days: float, elapsed_days: float | None, horizon_days: int = 30) -> float | None:
    if elapsed_days is None:
        return None
    return retention(interval_days, elapsed_days + horizon_days)


def mean(xs):
    xs = [x for x in xs if x is not None]
    return round(sum(xs) / len(xs), 4) if xs else None
