import base64
import hashlib
import hmac
import os
import secrets
from datetime import timedelta

import jwt
from cryptography.fernet import Fernet

from .config import settings
from .database import utcnow


# ---- passwords (scrypt, stdlib only) ----
def hash_password(password: str) -> str:
    salt = os.urandom(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, s, h = stored.split("$")
        salt, expected = base64.b64decode(s), base64.b64decode(h)
        dk = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(dk, expected)
    except Exception:
        return False


# ---- JWT ----
def create_token(user_id: int, remember: bool = False) -> tuple[str, int]:
    ttl = timedelta(days=settings.remember_me_days) if remember else timedelta(hours=settings.session_hours)
    exp = utcnow() + ttl
    token = jwt.encode({"sub": str(user_id), "exp": exp}, settings.jwt_secret, algorithm=settings.jwt_alg)
    return token, int(ttl.total_seconds())


def decode_token(token: str) -> int | None:
    try:
        return int(jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_alg])["sub"])
    except Exception:
        return None


# ---- misc tokens / hashes ----
def sha256(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


def new_api_key() -> tuple[str, str, str]:
    raw = "rc_" + secrets.token_urlsafe(32)
    return raw, raw[:10], sha256(raw)


# ---- vendor secret encryption (Fernet) ----
def _fernet() -> Fernet:
    key = settings.vendor_secret_key
    if not key:  # dev fallback: derive from JWT secret. Set VENDOR_SECRET_KEY in prod.
        key = base64.urlsafe_b64encode(hashlib.sha256(settings.jwt_secret.encode()).digest()).decode()
    return Fernet(key.encode())


def encrypt_secret(v: str) -> str:
    return _fernet().encrypt(v.encode()).decode()


def decrypt_secret(v: str) -> str:
    return _fernet().decrypt(v.encode()).decode()


def mask_secret(v: str) -> str:
    return "•" * 8 + v[-4:] if len(v) > 4 else "••••"
