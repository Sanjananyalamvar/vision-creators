from datetime import datetime

from .database import utcnow
from .models import Memory, User
from .services import srs


def elapsed_days(m: Memory, now: datetime | None = None) -> float | None:
    if not m.last_reviewed_at:
        return None
    return ((now or utcnow()) - m.last_reviewed_at).total_seconds() / 86400


def memory_retention(m: Memory, now=None):
    return srs.retention(m.interval_days, elapsed_days(m, now))


def due_label(m: Memory, now: datetime | None = None) -> str:
    now = now or utcnow()
    if m.due_at <= now:
        return "due_now"
    days = (m.due_at - now).total_seconds() / 86400
    return "due_today" if m.due_at.date() == now.date() else f"due_in_{max(1, round(days))}d"


def memory_out(m: Memory, now=None, include_answer=True) -> dict:
    now = now or utcnow()
    r = memory_retention(m, now)
    out = {
        "id": m.id, "title": m.title, "question": m.question, "content": m.content, "url": m.url,
        "source": m.source, "tags": m.tags or [], "deck_id": m.deck_id, "partition": m.partition,
        "pinned": m.pinned, "retention": r,
        "strength": None if r is None else "strong" if r >= 0.85 else "fair" if r >= 0.6 else "fading",
        "status": due_label(m, now), "due_at": m.due_at.isoformat(),
        "last_reviewed_at": m.last_reviewed_at.isoformat() if m.last_reviewed_at else None,
        "interval_days": m.interval_days, "recall_count": m.recall_count,
        "created_at": m.created_at.isoformat(),
    }
    if include_answer:
        out["answer"], out["hint"] = m.answer, m.hint
    return out


def user_out(u: User) -> dict:
    return {"id": u.id, "email": u.email, "handle": u.handle, "full_name": u.full_name,
            "title": u.title, "avatar_url": u.avatar_url}
