"""Pure-logic tests (no FastAPI/DB needed)."""
from app.services import srs, text
from app.services.pricing import budget_impact, build_quote


def test_sm2_progression():
    s = srs.CardState()
    s = srs.next_state(s, "good");  assert s.interval_days == 1 and s.repetitions == 1
    s = srs.next_state(s, "good");  assert s.interval_days == 4
    s = srs.next_state(s, "good");  assert s.interval_days == 4 * 2.5
    lapsed = srs.next_state(s, "again")
    assert lapsed.repetitions == 0 and lapsed.lapses == 1 and lapsed.interval_days < 0.01 and lapsed.ease < s.ease


def test_preview_labels():
    p = srs.preview(srs.CardState(2.5, 4.0, 2, 0))
    assert p["again"] == "10m" and p["good"] == "10d" and set(p) == set(srs.GRADES)


def test_retention_curve():
    assert srs.retention(4, None) is None
    assert srs.retention(4, 0) == 1.0
    assert abs(srs.retention(4, 4) - 0.9) < 1e-6
    assert srs.retention(4, 40) < srs.retention(4, 4)


def test_quote_matches_wireframe():
    q = build_quote([("Base", 1240.0, True), ("SLA", 350.0, True), ("ZK", 0.0, True)], 0.15, 0.08)
    assert q["discount"] == 238.5 and q["subtotal"] == 1590.0
    assert abs(q["total"] - 1459.65) < 0.1  # wireframe shows $1,459.65 (tax rate ≈ 8.0022%)


def test_budget_impact():
    assert budget_impact(0, 12500, 1459.65)["percent"] == 11.7 or budget_impact(0, 12500, 1459.65)["status"] == "healthy"
    assert budget_impact(12000, 12500, 1000)["status"] == "over_budget"


def test_text_utils():
    assert text.extract_tags("Kafka #Tech #architecture") == ["architecture", "tech"]
    assert text.is_url("https://example.com/a") and not text.is_url("hello world")
    assert text.similarity("kafka event log", "event log kafka") > 0.99
    assert text.jaccard("I train at 6:30 AM", "Gym sessions at 6:00 PM") < 0.5
