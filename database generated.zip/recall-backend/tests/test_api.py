"""End-to-end smoke test. Run: pytest -q   (uses a throw-away SQLite file)."""
import os, tempfile

os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"
os.environ["PROVISIONING_SIMULATION"] = "true"

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

API = "/api/v1"


def test_full_flow():
    with TestClient(app) as c:
        r = c.post(f"{API}/auth/signup", json={"full_name": "Alex Vance", "email": "alex@example.com", "password": "supersecret1"})
        assert r.status_code == 201, r.text
        h = {"Authorization": f"Bearer {r.json()['access_token']}"}
        assert c.post(f"{API}/auth/login", json={"identifier": "alex@example.com", "password": "nope"}).status_code == 401
        assert c.post(f"{API}/auth/login", json={"identifier": "alex@example.com", "password": "supersecret1", "remember_me": True}).status_code == 200

        deck = c.post(f"{API}/decks", json={"name": "Architecture"}, headers=h).json()
        for t in ["Kafka event log decouples producers and consumers #tech", "CAP theorem: pick two of C, A, P #tech"]:
            assert c.post(f"{API}/memories", json={"content": t, "deck_id": deck["id"]}, headers=h).status_code == 201

        dash = c.get(f"{API}/dashboard", headers=h).json()
        assert dash["queue"]["due"] == 2 and dash["greeting_name"] == "Alex"

        s = c.post(f"{API}/review/sessions", json={}, headers=h).json()
        for card in s["cards"]:
            a = c.post(f"{API}/review/sessions/{s['session_id']}/answer",
                       json={"memory_id": card["id"], "grade": "good", "response_ms": 1800}, headers=h)
            assert a.status_code == 200, a.text
        fin = c.post(f"{API}/review/sessions/{s['session_id']}/finish", headers=h).json()
        assert fin["reviewed"] == 2 and fin["accuracy"] == 1.0
        assert c.get(f"{API}/dashboard", headers=h).json()["streak_days"] == 1

        assert c.get(f"{API}/memories/search", params={"q": "kafka"}, headers=h).json()["results"]

        cc = c.get(f"{API}/procurement/cost-centers", headers=h).json()[0]
        o = c.post(f"{API}/procurement/orders", headers=h, json={
            "vendor_key": "pinecone", "plan_id": "enterprise-50m", "cost_center_id": cc["id"],
            "region": "us-east-1", "embed_dim": 1536}).json()
        assert o["status"] == "provisioning" and o["number"].startswith("PO-")
        assert c.get(f"{API}/procurement/orders/{o['id']}/invoice", headers=h).status_code == 200
        assert c.get(f"{API}/vendors/connections", headers=h).status_code == 200
        assert c.get(f"{API}/workspace", headers=h).json()["your_role"] == "owner"
